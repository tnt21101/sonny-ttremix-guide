import type { SourceAnalysis } from './analysis.types.js';
import type { SwapSpec } from './swap-spec.types.js';

export type SourceType = 'upload' | 'url';

export type SourcePlatform =
  | 'tiktok'
  | 'youtube'
  | 'x'
  | 'facebook'
  | 'direct-mp4'
  | 'upload';

export type RemixJobStatus =
  | 'pending'
  | 'ingesting'
  | 'analyzing'
  | 'generating'
  | 'polishing'
  | 'complete'
  | 'failed';

export type CaptionPreset = 'clean' | 'bold' | 'karaoke';

export interface TranscriptWord {
  word: string;
  start: number;
  end: number;
}

export interface RemixJob {
  id: string;
  userId: string;
  sourceType: SourceType;
  sourceUrl: string | null;
  sourcePlatform: SourcePlatform;
  sourceVideoStorageUrl: string | null;
  sourceDurationSeconds: number | null;
  sourceAspectRatio: string | null;
  transcript: string | null;
  transcriptWords: TranscriptWord[] | null;
  keyframeUrls: string[] | null;
  sourceAnalysis: SourceAnalysis | null;
  swapSpec: SwapSpec | null;
  preserveOriginalAudio: boolean;
  captionPreset: CaptionPreset | null;
  modelId: string | null;
  generatedVideoUrl: string | null;
  status: RemixJobStatus;
  errorMessage: string | null;
  costCents: number | null;
  createdAt: string;
  completedAt: string | null;
}
