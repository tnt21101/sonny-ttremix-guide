import type { SourceType, CaptionPreset, RemixJob } from './remix-job.types.js';
import type { SwapSpec } from './swap-spec.types.js';

export interface CreateRemixJobRequest {
  sourceType: SourceType;
  sourceUrl?: string;
  sourceStorageKey?: string;
  sourceFilename?: string;
}

export interface CreateRemixJobResponse {
  job: RemixJob;
}

export interface GetRemixJobResponse {
  job: RemixJob;
}

export interface ListRemixJobsResponse {
  jobs: RemixJob[];
}

export interface UpdateSwapSpecRequest {
  swapSpec: SwapSpec;
  preserveOriginalAudio: boolean;
  captionPreset: CaptionPreset;
}

export interface TriggerGenerateRequest {
  modelId: string;
}

export interface SaveRecipeRequest {
  recipeName: string;
}

export interface SignedUploadUrlRequest {
  filename: string;
  contentType: string;
  sizeBytes: number;
}

export interface SignedUploadUrlResponse {
  uploadUrl: string;
  storageKey: string;
  publicUrl: string;
}

export interface ApiError {
  error: string;
  code: string;
  details?: Record<string, unknown>;
}
