export interface CharacterSwap {
  mode: 'describe' | 'reference-image';
  description: string | null;
  referenceImageUrl: string | null;
}

export interface ProductSwap {
  // Phase 2 — populated when product swap is enabled.
  mode: 'describe' | 'reference-image';
  description: string | null;
  referenceImageUrl: string | null;
}

export interface SwapSpec {
  character: CharacterSwap;
  product: ProductSwap | null;
}
