export interface AnalysisCharacter {
  appearance: string;
  ageRange: string;
  vibe: string;
  genderPresentation: string;
}

export interface AnalysisProduct {
  detected: boolean;
  nameGuess: string | null;
  type: string | null;
  brandingVisible: boolean;
}

export interface AnalysisScene {
  setting: string;
  lighting: string;
  timeOfDay: string;
}

export interface AnalysisBlocking {
  framing: string;
  subjectPosition: string;
  cameraDistance: string;
}

export interface AnalysisCameraStyle {
  movement: string;
  angle: string;
  motionFeel: string;
}

export interface SourceAnalysis {
  character: AnalysisCharacter;
  product: AnalysisProduct;
  scene: AnalysisScene;
  blocking: AnalysisBlocking;
  cameraStyle: AnalysisCameraStyle;
  actions: string[];
  emotionalBeats: string[];
}
