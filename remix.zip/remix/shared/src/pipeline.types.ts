export interface IngestJobData {
  remixJobId: string;
  userId: string;
}

export interface AnalyzeJobData {
  remixJobId: string;
  userId: string;
}

export interface GenerateJobData {
  remixJobId: string;
  userId: string;
}

export interface PolishJobData {
  remixJobId: string;
  userId: string;
}

export const QUEUE_NAMES = {
  INGEST: 'remix-ingest',
  ANALYZE: 'remix-analyze',
  GENERATE: 'remix-generate',
  POLISH: 'remix-polish',
} as const;

export type QueueName = (typeof QUEUE_NAMES)[keyof typeof QUEUE_NAMES];
