export type AspectRatio = '9:16' | '16:9' | '1:1' | '4:3' | '3:4' | '21:9';

export interface VideoModel {
  id: string;
  label: string;
  provider: 'kie';
  kieModelSlug: string;
  maxDurationSeconds: number;
  supportedAspectRatios: AspectRatio[];
  costCentsPerSecond: number;
  isDefault: boolean;
  supportsReferenceVideo: boolean;
  supportsReferenceImage: boolean;
}
