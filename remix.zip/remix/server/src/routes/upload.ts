import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import type { SignedUploadUrlResponse } from '@remix/shared';
import { requireUser } from '../middleware/auth.js';
import { createSignedUploadUrl, publicUrlFor } from '../providers/storage-client.js';
import { RemixError } from '../lib/errors.js';
import { MAX_UPLOAD_BYTES, ALLOWED_UPLOAD_MIMES } from '../pipeline/ingest-source.js';

export const uploadRouter = Router();

const signedUrlSchema = z.object({
  filename: z.string().min(1).max(200),
  contentType: z.string().min(1),
  sizeBytes: z.number().int().positive(),
});

uploadRouter.post('/signed-url', requireUser, async (req, res, next) => {
  try {
    const parsed = signedUrlSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid upload request', {
        details: { issues: parsed.error.issues },
      });
    }
    const { filename, contentType, sizeBytes } = parsed.data;
    if (sizeBytes > MAX_UPLOAD_BYTES) {
      throw new RemixError('UPLOAD_TOO_LARGE', 'Upload exceeds 100MB limit');
    }
    if (!ALLOWED_UPLOAD_MIMES.includes(contentType as (typeof ALLOWED_UPLOAD_MIMES)[number])) {
      throw new RemixError('VALIDATION_ERROR', 'Only MP4 and MOV uploads are supported');
    }
    const safeName = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
    const storageKey = `uploads/${req.userInternalId}/${randomUUID()}/${safeName}`;
    const uploadUrl = await createSignedUploadUrl({ key: storageKey, contentType });
    const payload: SignedUploadUrlResponse = {
      uploadUrl,
      storageKey,
      publicUrl: publicUrlFor(storageKey),
    };
    res.json(payload);
  } catch (err) {
    next(err);
  }
});
