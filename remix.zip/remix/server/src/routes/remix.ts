import { Router } from 'express';
import { z } from 'zod';
import type {
  CreateRemixJobRequest,
  CreateRemixJobResponse,
  GetRemixJobResponse,
  ListRemixJobsResponse,
  SourcePlatform,
  SwapSpec,
  CaptionPreset,
} from '@remix/shared';
import { requireUser } from '../middleware/auth.js';
import { RemixError } from '../lib/errors.js';
import { detectPlatform } from '../lib/platform-detect.js';
import {
  createJob,
  getJob,
  listJobsForUser,
  updateJobForUser,
} from '../lib/job-repo.js';
import { ingestQueue, analyzeQueue, generateQueue } from '../lib/queues.js';
import { getModel, estimateCostCents, DEFAULT_MODEL_ID } from '../lib/model-registry.js';

export const remixRouter = Router();

const createSchema = z.object({
  sourceType: z.enum(['url', 'upload']),
  sourceUrl: z.string().url().optional(),
  sourceStorageKey: z.string().optional(),
  sourceFilename: z.string().optional(),
});

remixRouter.post('/', requireUser, async (req, res, next) => {
  try {
    const parsed = createSchema.safeParse(req.body as CreateRemixJobRequest);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid create-job payload', {
        details: { issues: parsed.error.issues },
      });
    }
    const body = parsed.data;
    let platform: SourcePlatform;
    let sourceUrl: string | null = null;
    let sourceVideoStorageUrl: string | null = null;

    if (body.sourceType === 'url') {
      if (!body.sourceUrl) {
        throw new RemixError('VALIDATION_ERROR', 'sourceUrl required for url sources');
      }
      platform = detectPlatform(body.sourceUrl);
      sourceUrl = body.sourceUrl;
    } else {
      if (!body.sourceStorageKey) {
        throw new RemixError(
          'VALIDATION_ERROR',
          'sourceStorageKey required for upload sources',
        );
      }
      platform = 'upload';
      // The signed-url endpoint guarantees the S3 object address.
      const { S3_BUCKET, AWS_REGION } = process.env;
      sourceVideoStorageUrl = `https://${S3_BUCKET}.s3.${AWS_REGION}.amazonaws.com/${body.sourceStorageKey}`;
    }

    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');

    const job = await createJob({
      userId,
      sourceType: body.sourceType,
      sourcePlatform: platform,
      sourceUrl,
      sourceVideoStorageUrl,
    });

    // Chain: ingest -> analyze (workers enqueue next step)
    await ingestQueue.add('ingest', { remixJobId: job.id, userId });

    const payload: CreateRemixJobResponse = { job };
    res.status(201).json(payload);
  } catch (err) {
    next(err);
  }
});

remixRouter.get('/', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const jobs = await listJobsForUser(userId);
    const payload: ListRemixJobsResponse = { jobs };
    res.json(payload);
  } catch (err) {
    next(err);
  }
});

remixRouter.get('/:id', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const job = await getJob(userId, req.params.id);
    if (!job) throw new RemixError('NOT_FOUND', 'Remix job not found');
    const payload: GetRemixJobResponse = { job };
    res.json(payload);
  } catch (err) {
    next(err);
  }
});

/** Re-runs analysis for a job that has already been ingested. */
remixRouter.post('/:id/reanalyze', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const job = await getJob(userId, req.params.id);
    if (!job) throw new RemixError('NOT_FOUND', 'Remix job not found');
    if (!job.sourceVideoStorageUrl) {
      throw new RemixError('VALIDATION_ERROR', 'Job must be ingested before re-analyzing');
    }
    await analyzeQueue.add('analyze', { remixJobId: job.id, userId });
    res.status(202).json({ ok: true });
  } catch (err) {
    next(err);
  }
});

const analysisSchema = z.object({
  character: z.object({
    appearance: z.string(),
    ageRange: z.string(),
    vibe: z.string(),
    genderPresentation: z.string(),
  }),
  product: z.object({
    detected: z.boolean(),
    nameGuess: z.string().nullable(),
    type: z.string().nullable(),
    brandingVisible: z.boolean(),
  }),
  scene: z.object({
    setting: z.string(),
    lighting: z.string(),
    timeOfDay: z.string(),
  }),
  blocking: z.object({
    framing: z.string(),
    subjectPosition: z.string(),
    cameraDistance: z.string(),
  }),
  cameraStyle: z.object({
    movement: z.string(),
    angle: z.string(),
    motionFeel: z.string(),
  }),
  actions: z.array(z.string()),
  emotionalBeats: z.array(z.string()),
});

remixRouter.patch('/:id/analysis', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const parsed = analysisSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid analysis payload', {
        details: { issues: parsed.error.issues },
      });
    }
    const updated = await updateJobForUser(userId, req.params.id, {
      sourceAnalysis: parsed.data,
    });
    res.json({ job: updated });
  } catch (err) {
    next(err);
  }
});

const swapSpecSchema = z.object({
  swapSpec: z.object({
    character: z.object({
      mode: z.enum(['describe', 'reference-image']),
      description: z.string().nullable(),
      referenceImageUrl: z.string().url().nullable(),
    }),
    product: z.null(), // Phase 1: product swap disabled.
  }),
  preserveOriginalAudio: z.boolean(),
  captionPreset: z.enum(['clean', 'bold', 'karaoke']),
});

remixRouter.patch('/:id/swap-spec', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const parsed = swapSpecSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid swap-spec payload', {
        details: { issues: parsed.error.issues },
      });
    }
    const swapSpec: SwapSpec = {
      character: parsed.data.swapSpec.character,
      product: null,
    };
    const captionPreset: CaptionPreset = parsed.data.captionPreset;
    const updated = await updateJobForUser(userId, req.params.id, {
      swapSpec,
      preserveOriginalAudio: parsed.data.preserveOriginalAudio,
      captionPreset,
    });
    res.json({ job: updated });
  } catch (err) {
    next(err);
  }
});

const generateSchema = z.object({
  modelId: z.string().min(1),
});

remixRouter.post('/:id/generate', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const parsed = generateSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid generate payload');
    }
    const job = await getJob(userId, req.params.id);
    if (!job) throw new RemixError('NOT_FOUND', 'Remix job not found');
    if (!job.sourceAnalysis || !job.swapSpec) {
      throw new RemixError(
        'VALIDATION_ERROR',
        'Job must have analysis and swap spec before generation',
      );
    }
    const model = getModel(parsed.data.modelId) ?? getModel(DEFAULT_MODEL_ID);
    if (!model) throw new RemixError('VALIDATION_ERROR', 'Unknown model id');
    await updateJobForUser(userId, req.params.id, {
      modelId: model.id,
      costCents: estimateCostCents(model.id, job.sourceDurationSeconds ?? 10),
    });
    await generateQueue.add('generate', { remixJobId: job.id, userId });
    res.status(202).json({ ok: true, modelId: model.id });
  } catch (err) {
    next(err);
  }
});

const costSchema = z.object({
  modelId: z.string().min(1),
  durationSeconds: z.number().int().positive(),
});
remixRouter.post('/cost-estimate', requireUser, (req, res, next) => {
  try {
    const parsed = costSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid cost estimate payload');
    }
    const cents = estimateCostCents(parsed.data.modelId, parsed.data.durationSeconds);
    res.json({ costCents: cents });
  } catch (err) {
    next(err);
  }
});
