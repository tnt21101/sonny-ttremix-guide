import { Router } from 'express';
import { requireUser } from '../middleware/auth.js';

export const authRouter = Router();

/**
 * Returns the authenticated user's internal id + email. Clerk handles the
 * sign-in/sign-up flow on the client; this endpoint exists so the client can
 * confirm server-side session state and trigger the user upsert.
 */
authRouter.get('/me', requireUser, (req, res) => {
  res.json({
    id: req.userInternalId,
    email: req.userEmail,
  });
});
