import { Router } from 'express';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { remixRecipes } from '@remix/db';
import { requireUser } from '../middleware/auth.js';
import { RemixError } from '../lib/errors.js';
import { withUserContext } from '../lib/db.js';
import { getJob } from '../lib/job-repo.js';

export const recipesRouter = Router();

const saveSchema = z.object({
  recipeName: z.string().min(1).max(200),
  sourceJobId: z.string().uuid(),
});

/**
 * Phase 1 stub: persists the recipe row so Phase 2 can pick it up. The row's
 * swap_template mirrors the job's swap_spec and preserve fields capture the
 * locked-in analysis fields so future batch runs can enforce them.
 */
recipesRouter.post('/', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const parsed = saveSchema.safeParse(req.body);
    if (!parsed.success) {
      throw new RemixError('VALIDATION_ERROR', 'Invalid recipe payload');
    }
    const job = await getJob(userId, parsed.data.sourceJobId);
    if (!job) throw new RemixError('NOT_FOUND', 'Source job not found');

    const recipe = await withUserContext(userId, async (tx) => {
      const [row] = await tx
        .insert(remixRecipes)
        .values({
          userId,
          sourceJobId: job.id,
          recipeName: parsed.data.recipeName,
          preserveFields: {
            scene: job.sourceAnalysis?.scene ?? null,
            blocking: job.sourceAnalysis?.blocking ?? null,
            cameraStyle: job.sourceAnalysis?.cameraStyle ?? null,
            captionPreset: job.captionPreset ?? null,
            preserveOriginalAudio: job.preserveOriginalAudio,
          },
          swapTemplate: job.swapSpec,
        })
        .returning();
      return row;
    });
    res.status(201).json({ recipe });
  } catch (err) {
    next(err);
  }
});

recipesRouter.get('/', requireUser, async (req, res, next) => {
  try {
    const userId = req.userInternalId;
    if (!userId) throw new RemixError('UNAUTHORIZED', 'Missing user context');
    const recipes = await withUserContext(userId, async (tx) => {
      return tx.select().from(remixRecipes).where(eq(remixRecipes.userId, userId));
    });
    res.json({ recipes });
  } catch (err) {
    next(err);
  }
});
