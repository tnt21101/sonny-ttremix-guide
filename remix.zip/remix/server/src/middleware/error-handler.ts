import type { Request, Response, NextFunction } from 'express';
import { isRemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction): void {
  if (isRemixError(err)) {
    res.status(err.statusCode).json(err.toJSON());
    return;
  }
  const message = err instanceof Error ? err.message : 'Internal server error';
  logger.error('unhandled error', { path: req.path, message });
  res.status(500).json({ error: message, code: 'INTERNAL_ERROR' });
}
