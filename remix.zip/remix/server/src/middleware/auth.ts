import { clerkMiddleware, getAuth, clerkClient } from '@clerk/express';
import type { Request, Response, NextFunction } from 'express';
import { RemixError } from '../lib/errors.js';
import { upsertUser } from '../lib/job-repo.js';

export const clerkAuth = clerkMiddleware();

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      userInternalId?: string;
      userEmail?: string;
    }
  }
}

/**
 * Resolves the Clerk user to our internal users.id (uuid) and attaches it to
 * the request. Any route behind this middleware is guaranteed to have a
 * matching row in the users table.
 */
export async function requireUser(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const auth = getAuth(req);
    if (!auth.userId) {
      throw new RemixError('UNAUTHORIZED', 'Sign-in required');
    }
    const user = await clerkClient.users.getUser(auth.userId);
    const email =
      user.primaryEmailAddress?.emailAddress ??
      user.emailAddresses[0]?.emailAddress ??
      `${auth.userId}@placeholder.local`;
    const { id } = await upsertUser({ externalId: auth.userId, email });
    req.userInternalId = id;
    req.userEmail = email;
    next();
  } catch (err) {
    next(err);
  }
}
