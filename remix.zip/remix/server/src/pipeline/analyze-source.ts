import { mkdir, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { request } from 'undici';
import { createWriteStream } from 'node:fs';
import { pipeline as streamPipeline } from 'node:stream/promises';
import type { SourceAnalysis, TranscriptWord } from '@remix/shared';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { extractAudio, extractKeyframes } from '../lib/ffmpeg.js';
import { uploadFile } from '../providers/storage-client.js';
import { transcribeAudio } from '../providers/whisper-client.js';
import { analyzeKeyframes } from '../providers/anthropic-client.js';

export interface AnalysisResult {
  keyframeUrls: string[];
  transcript: string;
  transcriptWords: TranscriptWord[];
  analysis: SourceAnalysis;
}

const KEYFRAME_COUNT = 5;

export async function analyzeSource(params: {
  jobId: string;
  sourceVideoUrl: string;
  durationSeconds: number;
}): Promise<AnalysisResult> {
  const workDir = join(tmpdir(), `remix-analyze-${params.jobId}-${randomUUID()}`);
  await mkdir(workDir, { recursive: true });
  try {
    const videoPath = join(workDir, 'source.mp4');
    await downloadToFile(params.sourceVideoUrl, videoPath);

    const keyframesDir = join(workDir, 'keyframes');
    const keyframePaths = await extractKeyframes({
      inputPath: videoPath,
      outputDir: keyframesDir,
      count: KEYFRAME_COUNT,
      durationSeconds: params.durationSeconds,
    });

    const audioPath = join(workDir, 'audio.mp3');
    await extractAudio({ inputPath: videoPath, outputPath: audioPath });

    const { transcript, words } = await transcribeAudio(audioPath);

    const keyframeUrls = await Promise.all(
      keyframePaths.map(async (path, idx) => {
        const key = `sources/${params.jobId}/keyframes/keyframe-${idx + 1}.jpg`;
        return uploadFile({ key, localPath: path, contentType: 'image/jpeg' });
      }),
    );

    const analysis = await analyzeKeyframes({ keyframePaths, transcript });

    await safeCleanup(workDir);

    return {
      keyframeUrls,
      transcript,
      transcriptWords: words,
      analysis,
    };
  } catch (err) {
    await safeCleanup(workDir);
    if (err instanceof RemixError) throw err;
    logger.error('analyzeSource failed', { err: String(err), jobId: params.jobId });
    throw new RemixError('ANALYZE_FAILED', 'Analysis pipeline failed', { cause: err });
  }
}

async function downloadToFile(url: string, outputPath: string): Promise<void> {
  const res = await request(url);
  if (res.statusCode >= 400) {
    throw new RemixError('ANALYZE_FAILED', `Failed to download source video (${res.statusCode})`);
  }
  await streamPipeline(res.body, createWriteStream(outputPath));
}

async function safeCleanup(dir: string): Promise<void> {
  try {
    await rm(dir, { recursive: true, force: true });
  } catch (err) {
    logger.warn('cleanup failed', { dir, err: String(err) });
  }
}
