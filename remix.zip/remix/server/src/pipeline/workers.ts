import { Worker } from 'bullmq';
import { QUEUE_NAMES } from '@remix/shared';
import type {
  IngestJobData,
  AnalyzeJobData,
  GenerateJobData,
  PolishJobData,
} from '@remix/shared';
import { redis, analyzeQueue, polishQueue } from '../lib/queues.js';
import { getJobInternal, updateJobInternal } from '../lib/job-repo.js';
import { RemixError, isRemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { ingestFromUrl, ingestFromUpload } from './ingest-source.js';
import { analyzeSource } from './analyze-source.js';
import { generateRemix } from './generate-remix.js';
import { polishRemix } from './polish-remix.js';
import { request } from 'undici';
import { createWriteStream } from 'node:fs';
import { mkdir } from 'node:fs/promises';
import { pipeline as streamPipeline } from 'node:stream/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';

async function recordFailure(jobId: string, err: unknown): Promise<void> {
  const message = isRemixError(err) ? err.message : err instanceof Error ? err.message : String(err);
  const code = isRemixError(err) ? err.code : 'INTERNAL_ERROR';
  logger.error('pipeline step failed', { jobId, code, message });
  await updateJobInternal(jobId, {
    status: 'failed',
    errorMessage: `[${code}] ${message}`,
    completedAt: new Date(),
  });
}

export function startWorkers(): {
  workers: Worker[];
  close: () => Promise<void>;
} {
  const ingestWorker = new Worker<IngestJobData>(
    QUEUE_NAMES.INGEST,
    async (job) => {
      const { remixJobId } = job.data;
      await updateJobInternal(remixJobId, { status: 'ingesting' });
      const remixJob = await getJobInternal(remixJobId);
      if (!remixJob) throw new RemixError('NOT_FOUND', 'Remix job not found');

      let result;
      if (remixJob.sourceType === 'url') {
        if (!remixJob.sourceUrl) {
          throw new RemixError('VALIDATION_ERROR', 'URL source has no sourceUrl');
        }
        result = await ingestFromUrl({
          url: remixJob.sourceUrl,
          platform: remixJob.sourcePlatform,
          jobId: remixJob.id,
        });
      } else {
        // upload: caller already stored the raw upload in S3 under
        // sourceVideoStorageUrl. Download it, validate, and re-store.
        if (!remixJob.sourceVideoStorageUrl) {
          throw new RemixError('VALIDATION_ERROR', 'Upload source has no storage URL');
        }
        const workDir = join(tmpdir(), `remix-w-${remixJob.id}-${randomUUID()}`);
        await mkdir(workDir, { recursive: true });
        const localPath = join(workDir, 'upload.bin');
        const res = await request(remixJob.sourceVideoStorageUrl);
        if (res.statusCode >= 400) {
          throw new RemixError('INGEST_FAILED', `Failed to fetch upload (${res.statusCode})`);
        }
        await streamPipeline(res.body, createWriteStream(localPath));
        const headRes = await request(remixJob.sourceVideoStorageUrl, { method: 'HEAD' });
        const contentLength = Number(headRes.headers['content-length'] ?? 0);
        const contentType = String(headRes.headers['content-type'] ?? 'video/mp4');
        result = await ingestFromUpload({
          inputPath: localPath,
          contentType,
          sizeBytes: contentLength,
          jobId: remixJob.id,
        });
      }

      await updateJobInternal(remixJobId, {
        sourceVideoStorageUrl: result.storageUrl,
        sourceDurationSeconds: result.durationSeconds,
        sourceAspectRatio: result.aspectRatio,
      });

      // chain next step
      await analyzeQueue.add('analyze', { remixJobId, userId: job.data.userId });
    },
    { connection: redis, concurrency: 2 },
  );
  ingestWorker.on('failed', async (job, err) => {
    if (job) await recordFailure(job.data.remixJobId, err);
  });

  const analyzeWorker = new Worker<AnalyzeJobData>(
    QUEUE_NAMES.ANALYZE,
    async (job) => {
      const { remixJobId } = job.data;
      await updateJobInternal(remixJobId, { status: 'analyzing' });
      const remixJob = await getJobInternal(remixJobId);
      if (!remixJob) throw new RemixError('NOT_FOUND', 'Remix job not found');
      if (!remixJob.sourceVideoStorageUrl || remixJob.sourceDurationSeconds === null) {
        throw new RemixError('ANALYZE_FAILED', 'Job missing ingested source data');
      }
      const result = await analyzeSource({
        jobId: remixJobId,
        sourceVideoUrl: remixJob.sourceVideoStorageUrl,
        durationSeconds: remixJob.sourceDurationSeconds,
      });
      await updateJobInternal(remixJobId, {
        keyframeUrls: result.keyframeUrls,
        transcript: result.transcript,
        transcriptWords: result.transcriptWords,
        sourceAnalysis: result.analysis,
        // After analysis we pause for the user to edit + configure swap spec
        // and hit Generate. Status becomes 'pending' again but with
        // analysis data present, which the client uses to advance to step 3.
        status: 'pending',
      });
    },
    { connection: redis, concurrency: 2 },
  );
  analyzeWorker.on('failed', async (job, err) => {
    if (job) await recordFailure(job.data.remixJobId, err);
  });

  const generateWorker = new Worker<GenerateJobData>(
    QUEUE_NAMES.GENERATE,
    async (job) => {
      const { remixJobId } = job.data;
      await updateJobInternal(remixJobId, { status: 'generating' });
      const remixJob = await getJobInternal(remixJobId);
      if (!remixJob) throw new RemixError('NOT_FOUND', 'Remix job not found');
      if (!remixJob.modelId) throw new RemixError('VALIDATION_ERROR', 'modelId not set');
      const result = await generateRemix({
        job: remixJob,
        requestedModelId: remixJob.modelId,
      });
      await updateJobInternal(remixJobId, {
        generatedVideoUrl: result.generatedVideoUrl,
        modelId: result.modelIdUsed,
        costCents: result.costCents,
        status: 'polishing',
      });
      await polishQueue.add('polish', { remixJobId, userId: job.data.userId });
    },
    { connection: redis, concurrency: 1 },
  );
  generateWorker.on('failed', async (job, err) => {
    if (job) await recordFailure(job.data.remixJobId, err);
  });

  const polishWorker = new Worker<PolishJobData>(
    QUEUE_NAMES.POLISH,
    async (job) => {
      const { remixJobId } = job.data;
      const remixJob = await getJobInternal(remixJobId);
      if (!remixJob) throw new RemixError('NOT_FOUND', 'Remix job not found');
      if (!remixJob.generatedVideoUrl || !remixJob.sourceVideoStorageUrl) {
        throw new RemixError('POLISH_FAILED', 'Job missing video URLs for polish');
      }
      const result = await polishRemix({
        jobId: remixJobId,
        generatedVideoUrl: remixJob.generatedVideoUrl,
        sourceVideoUrl: remixJob.sourceVideoStorageUrl,
        transcriptWords: remixJob.transcriptWords ?? [],
        captionPreset: remixJob.captionPreset ?? 'clean',
        preserveOriginalAudio: remixJob.preserveOriginalAudio,
      });
      await updateJobInternal(remixJobId, {
        generatedVideoUrl: result.finalVideoUrl,
        status: 'complete',
        completedAt: new Date(),
      });
    },
    { connection: redis, concurrency: 2 },
  );
  polishWorker.on('failed', async (job, err) => {
    if (job) await recordFailure(job.data.remixJobId, err);
  });

  const workers = [ingestWorker, analyzeWorker, generateWorker, polishWorker];
  return {
    workers,
    close: async () => {
      await Promise.all(workers.map((w) => w.close()));
    },
  };
}
