import type { RemixJob } from '@remix/shared';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import {
  getModel,
  DEFAULT_MODEL_ID,
  FALLBACK_MODEL_ID,
  estimateCostCents,
} from '../lib/model-registry.js';
import { buildRemixPrompt } from './build-remix-prompt.js';
import { submitKieTask, pollKieTask } from '../providers/kie-client.js';

export interface GenerateResult {
  generatedVideoUrl: string;
  modelIdUsed: string;
  costCents: number;
}

export interface GenerateOptions {
  job: RemixJob;
  requestedModelId: string;
  onProgress?: (message: string) => Promise<void> | void;
}

/**
 * Submits the job to KIE with the requested model. On failure, retries once
 * against the fallback model (unless the user explicitly chose a non-default).
 */
export async function generateRemix({
  job,
  requestedModelId,
  onProgress,
}: GenerateOptions): Promise<GenerateResult> {
  const primary = getModel(requestedModelId);
  if (!primary) {
    throw new RemixError('VALIDATION_ERROR', `Unknown model: ${requestedModelId}`);
  }

  const { prompt, referenceVideoUrl, referenceImageUrls } = buildRemixPrompt(job);
  const aspectRatio = coerceAspectRatio(job.sourceAspectRatio, primary.supportedAspectRatios);
  const durationSeconds = Math.min(job.sourceDurationSeconds ?? 10, primary.maxDurationSeconds);

  try {
    const result = await runOne({
      modelId: primary.id,
      kieModelSlug: primary.kieModelSlug,
      prompt,
      referenceVideoUrl,
      referenceImageUrls,
      aspectRatio,
      durationSeconds,
      onProgress,
    });
    return {
      ...result,
      modelIdUsed: primary.id,
      costCents: estimateCostCents(primary.id, durationSeconds),
    };
  } catch (err) {
    const isDefault = primary.id === DEFAULT_MODEL_ID;
    const fallback = getModel(FALLBACK_MODEL_ID);
    if (!isDefault || !fallback) {
      throw err;
    }
    logger.warn('primary generation failed; retrying with fallback', {
      primary: primary.id,
      fallback: fallback.id,
      err: String(err),
    });
    if (onProgress) await onProgress(`Primary model failed; retrying with ${fallback.label}`);
    const fallbackResult = await runOne({
      modelId: fallback.id,
      kieModelSlug: fallback.kieModelSlug,
      prompt,
      referenceVideoUrl,
      referenceImageUrls: fallback.supportsReferenceImage ? referenceImageUrls : [],
      aspectRatio: coerceAspectRatio(job.sourceAspectRatio, fallback.supportedAspectRatios),
      durationSeconds: Math.min(
        job.sourceDurationSeconds ?? 10,
        fallback.maxDurationSeconds,
      ),
      onProgress,
    });
    return {
      ...fallbackResult,
      modelIdUsed: fallback.id,
      costCents: estimateCostCents(fallback.id, durationSeconds),
    };
  }
}

interface RunOneParams {
  modelId: string;
  kieModelSlug: string;
  prompt: string;
  referenceVideoUrl: string;
  referenceImageUrls: string[];
  aspectRatio: string;
  durationSeconds: number;
  onProgress?: (message: string) => Promise<void> | void;
}

async function runOne(params: RunOneParams): Promise<{ generatedVideoUrl: string }> {
  const { taskId } = await submitKieTask({
    modelSlug: params.kieModelSlug,
    prompt: params.prompt,
    referenceVideoUrl: params.referenceVideoUrl,
    referenceImageUrls: params.referenceImageUrls,
    aspectRatio: params.aspectRatio,
    durationSeconds: params.durationSeconds,
  });
  if (params.onProgress) await params.onProgress(`KIE task submitted (${taskId})`);
  const final = await pollKieTask({
    taskId,
    intervalMs: 5_000,
    timeoutMs: 10 * 60_000,
    onUpdate: async (s) => {
      if (params.onProgress) {
        await params.onProgress(`KIE status: ${s.status}`);
      }
    },
  });
  if (final.status !== 'succeeded' || !final.videoUrl) {
    throw new RemixError('GENERATE_FAILED', final.errorMessage ?? 'KIE generation failed', {
      details: { taskId },
    });
  }
  return { generatedVideoUrl: final.videoUrl };
}

function coerceAspectRatio(sourceAspect: string | null, supported: readonly string[]): string {
  if (sourceAspect && supported.includes(sourceAspect)) return sourceAspect;
  // Default to vertical since Remix is TikTok-first.
  if (supported.includes('9:16')) return '9:16';
  return supported[0] ?? '9:16';
}
