import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../providers/storage-client.js', () => ({
  uploadFile: vi.fn(async (opts: { key: string }) => `https://stub/${opts.key}`),
  createSignedUploadUrl: vi.fn(),
  createSignedDownloadUrl: vi.fn(),
  publicUrlFor: vi.fn((key: string) => `https://stub/${key}`),
  extractKeyFromUrl: vi.fn(),
}));

vi.mock('../lib/ffmpeg.js', () => ({
  probeVideo: vi.fn(),
  extractKeyframes: vi.fn(async () => [
    '/tmp/kf-1.jpg',
    '/tmp/kf-2.jpg',
    '/tmp/kf-3.jpg',
    '/tmp/kf-4.jpg',
    '/tmp/kf-5.jpg',
  ]),
  extractAudio: vi.fn(async (opts: { outputPath: string }) => opts.outputPath),
  muxVideoWithAudio: vi.fn(),
  burnCaptions: vi.fn(),
  aspectRatioFrom: vi.fn(() => '9:16'),
}));

vi.mock('../providers/whisper-client.js', () => ({
  transcribeAudio: vi.fn(async () => ({
    transcript: 'hello world',
    words: [
      { word: 'hello', start: 0, end: 0.5 },
      { word: 'world', start: 0.5, end: 1 },
    ],
  })),
}));

vi.mock('../providers/anthropic-client.js', () => ({
  analyzeKeyframes: vi.fn(async () => ({
    character: {
      appearance: 'woman with dark hair',
      ageRange: '20-30',
      vibe: 'confident',
      genderPresentation: 'feminine',
    },
    product: {
      detected: true,
      nameGuess: 'protein bar',
      type: 'food',
      brandingVisible: true,
    },
    scene: { setting: 'kitchen', lighting: 'bright', timeOfDay: 'morning' },
    blocking: { framing: 'medium', subjectPosition: 'center', cameraDistance: 'close' },
    cameraStyle: { movement: 'static', angle: 'eye-level', motionFeel: 'calm' },
    actions: ['reaches for bar', 'takes a bite'],
    emotionalBeats: ['curious', 'satisfied'],
  })),
}));

vi.mock('undici', () => ({
  request: vi.fn(async () => ({
    statusCode: 200,
    body: {
      // a readable-stream stub that emits nothing and ends immediately
      pipe: (dest: NodeJS.WritableStream) => dest.end(),
      on: () => undefined,
      async *[Symbol.asyncIterator](): AsyncGenerator<Buffer> {
        // yields nothing
      },
    },
  })),
}));

// node:stream/promises.pipeline — we make it a no-op because the body stub
// above has no real chunks.
vi.mock('node:stream/promises', () => ({
  pipeline: vi.fn(async () => undefined),
}));

// createWriteStream — return a stub that "ends"
vi.mock('node:fs', async (orig) => {
  const real = (await orig()) as typeof import('node:fs');
  return {
    ...real,
    createWriteStream: vi.fn(() => ({ end: (): void => undefined })),
  };
});

// Import after mocks are set up
const { analyzeSource } = await import('./analyze-source.js');

describe('analyze-source', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('produces keyframe urls, transcript, words, and analysis', async () => {
    const result = await analyzeSource({
      jobId: 'job-1',
      sourceVideoUrl: 'https://stub/sources/job-1/source.mp4',
      durationSeconds: 10,
    });
    expect(result.keyframeUrls).toHaveLength(5);
    for (const url of result.keyframeUrls) {
      expect(url).toContain('sources/job-1/keyframes/');
    }
    expect(result.transcript).toBe('hello world');
    expect(result.transcriptWords).toHaveLength(2);
    expect(result.analysis.character.appearance).toContain('woman');
    expect(result.analysis.product.detected).toBe(true);
    expect(result.analysis.actions.length).toBeGreaterThan(0);
  });
});
