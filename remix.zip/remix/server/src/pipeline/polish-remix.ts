import { mkdir, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { request } from 'undici';
import { createWriteStream } from 'node:fs';
import { pipeline as streamPipeline } from 'node:stream/promises';
import type { CaptionPreset, TranscriptWord } from '@remix/shared';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { burnCaptions, extractAudio, muxVideoWithAudio } from '../lib/ffmpeg.js';
import { uploadFile } from '../providers/storage-client.js';

export interface PolishResult {
  finalVideoUrl: string;
}

export interface PolishOptions {
  jobId: string;
  generatedVideoUrl: string;
  sourceVideoUrl: string;
  transcriptWords: TranscriptWord[];
  captionPreset: CaptionPreset;
  preserveOriginalAudio: boolean;
}

export async function polishRemix(options: PolishOptions): Promise<PolishResult> {
  const workDir = join(tmpdir(), `remix-polish-${options.jobId}-${randomUUID()}`);
  await mkdir(workDir, { recursive: true });
  try {
    const generatedPath = join(workDir, 'generated.mp4');
    await downloadToFile(options.generatedVideoUrl, generatedPath);

    let videoWithAudio = generatedPath;
    if (options.preserveOriginalAudio) {
      const sourcePath = join(workDir, 'source.mp4');
      await downloadToFile(options.sourceVideoUrl, sourcePath);
      const audioPath = join(workDir, 'source.mp3');
      await extractAudio({ inputPath: sourcePath, outputPath: audioPath });
      videoWithAudio = join(workDir, 'with-audio.mp4');
      await muxVideoWithAudio({
        videoPath: generatedPath,
        audioPath,
        outputPath: videoWithAudio,
      });
    }

    const srtPath = join(workDir, 'captions.srt');
    const srt = renderSrt(options.transcriptWords, options.captionPreset);
    await writeFile(srtPath, srt, 'utf8');

    const finalPath = join(workDir, 'final.mp4');
    await burnCaptions({ videoPath: videoWithAudio, srtPath, outputPath: finalPath });

    const storageKey = `outputs/${options.jobId}/final.mp4`;
    const finalVideoUrl = await uploadFile({
      key: storageKey,
      localPath: finalPath,
      contentType: 'video/mp4',
    });

    await safeCleanup(workDir);
    return { finalVideoUrl };
  } catch (err) {
    await safeCleanup(workDir);
    if (err instanceof RemixError) throw err;
    logger.error('polishRemix failed', { err: String(err) });
    throw new RemixError('POLISH_FAILED', 'Polish step failed', { cause: err });
  }
}

async function downloadToFile(url: string, outputPath: string): Promise<void> {
  const res = await request(url);
  if (res.statusCode >= 400) {
    throw new RemixError('POLISH_FAILED', `Failed to download video for polish (${res.statusCode})`);
  }
  await streamPipeline(res.body, createWriteStream(outputPath));
}

/**
 * Renders an SRT subtitle track.
 * - clean: simple sentence-level groupings (~4 words per cue)
 * - bold: sentence-level with ALL CAPS
 * - karaoke: word-by-word cues
 */
export function renderSrt(words: TranscriptWord[], preset: CaptionPreset): string {
  if (words.length === 0) return '';
  const cues: Array<{ start: number; end: number; text: string }> = [];
  if (preset === 'karaoke') {
    for (const w of words) {
      cues.push({ start: w.start, end: w.end, text: w.word.trim() });
    }
  } else {
    const groupSize = 4;
    for (let i = 0; i < words.length; i += groupSize) {
      const group = words.slice(i, i + groupSize);
      const first = group[0];
      const last = group[group.length - 1];
      if (!first || !last) continue;
      const text = group
        .map((w) => w.word.trim())
        .join(' ')
        .trim();
      cues.push({
        start: first.start,
        end: last.end,
        text: preset === 'bold' ? text.toUpperCase() : text,
      });
    }
  }
  return cues
    .map((cue, i) => `${i + 1}\n${toSrtTime(cue.start)} --> ${toSrtTime(cue.end)}\n${cue.text}\n`)
    .join('\n');
}

function toSrtTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds - Math.floor(seconds)) * 1000);
  return `${pad(h, 2)}:${pad(m, 2)}:${pad(s, 2)},${pad(ms, 3)}`;
}
function pad(n: number, width: number): string {
  return String(n).padStart(width, '0');
}

async function safeCleanup(dir: string): Promise<void> {
  try {
    await rm(dir, { recursive: true, force: true });
  } catch (err) {
    logger.warn('cleanup failed', { dir, err: String(err) });
  }
}
