import type { RemixJob, SourceAnalysis, SwapSpec } from '@remix/shared';
import { RemixError } from '../lib/errors.js';

export interface BuildPromptResult {
  prompt: string;
  referenceVideoUrl: string;
  referenceImageUrls: string[];
}

/**
 * Assembles the generation prompt from the source analysis and swap spec.
 * Phase 1 supports character swap only; product swap slots are preserved in
 * the template so Phase 2 can drop in.
 */
export function buildRemixPrompt(job: RemixJob): BuildPromptResult {
  const { sourceAnalysis, swapSpec, sourceVideoStorageUrl, transcript } = job;
  if (!sourceAnalysis) {
    throw new RemixError('VALIDATION_ERROR', 'Source analysis is required to build a prompt');
  }
  if (!swapSpec) {
    throw new RemixError('VALIDATION_ERROR', 'Swap spec is required to build a prompt');
  }
  if (!sourceVideoStorageUrl) {
    throw new RemixError('VALIDATION_ERROR', 'Source video URL is required to build a prompt');
  }

  const characterDescription = describeCharacter(swapSpec);
  const productDescription = describeProduct(swapSpec, sourceAnalysis);
  const scriptLine = transcript
    ? `Script (enforce as dialogue): ${sanitize(transcript)}`
    : 'Script: (no spoken dialogue — preserve original pacing and non-verbal actions)';

  const prompt = [
    'Recreate this video scene exactly as shown in @Video1.',
    `Character is now ${characterDescription}.`,
    `Product is ${productDescription}.`,
    'Preserve: script, camera movement, blocking, emotional arc, transitions, pacing.',
    scriptLine,
    '',
    'Scene context (must match):',
    `- Setting: ${sourceAnalysis.scene.setting}`,
    `- Lighting: ${sourceAnalysis.scene.lighting}`,
    `- Time of day: ${sourceAnalysis.scene.timeOfDay}`,
    `- Framing: ${sourceAnalysis.blocking.framing}, subject ${sourceAnalysis.blocking.subjectPosition}, distance ${sourceAnalysis.blocking.cameraDistance}`,
    `- Camera: ${sourceAnalysis.cameraStyle.movement}, ${sourceAnalysis.cameraStyle.angle}, ${sourceAnalysis.cameraStyle.motionFeel}`,
    sourceAnalysis.actions.length > 0
      ? `- Key actions: ${sourceAnalysis.actions.join('; ')}`
      : '',
    sourceAnalysis.emotionalBeats.length > 0
      ? `- Emotional beats: ${sourceAnalysis.emotionalBeats.join('; ')}`
      : '',
  ]
    .filter((l) => l.length > 0)
    .join('\n');

  const referenceImageUrls: string[] = [];
  if (swapSpec.character.mode === 'reference-image' && swapSpec.character.referenceImageUrl) {
    referenceImageUrls.push(swapSpec.character.referenceImageUrl);
  }
  if (
    swapSpec.product &&
    swapSpec.product.mode === 'reference-image' &&
    swapSpec.product.referenceImageUrl
  ) {
    referenceImageUrls.push(swapSpec.product.referenceImageUrl);
  }

  return {
    prompt,
    referenceVideoUrl: sourceVideoStorageUrl,
    referenceImageUrls,
  };
}

function describeCharacter(swapSpec: SwapSpec): string {
  const c = swapSpec.character;
  if (c.mode === 'reference-image' && c.referenceImageUrl) {
    return `the character shown in the attached reference image${c.description ? ` (${sanitize(c.description)})` : ''}`;
  }
  if (c.description && c.description.trim().length > 0) {
    return sanitize(c.description);
  }
  throw new RemixError('VALIDATION_ERROR', 'Character swap requires description or reference image');
}

function describeProduct(swapSpec: SwapSpec, analysis: SourceAnalysis): string {
  if (swapSpec.product) {
    if (swapSpec.product.mode === 'reference-image' && swapSpec.product.referenceImageUrl) {
      return `the product shown in the attached reference image${swapSpec.product.description ? ` (${sanitize(swapSpec.product.description)})` : ''}`;
    }
    if (swapSpec.product.description && swapSpec.product.description.trim().length > 0) {
      return sanitize(swapSpec.product.description);
    }
  }
  // Phase 1: fall back to the originally detected product so we don't drop it.
  if (analysis.product.detected) {
    const parts = [analysis.product.nameGuess, analysis.product.type].filter(
      (x): x is string => typeof x === 'string' && x.length > 0,
    );
    return parts.length > 0 ? `the original ${parts.join(' ')}` : 'the original product shown';
  }
  return 'no specific product; keep any incidental props intact';
}

function sanitize(input: string): string {
  return input.replace(/\s+/g, ' ').trim();
}
