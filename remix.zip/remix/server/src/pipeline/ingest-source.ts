import { mkdir, stat, rm } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { pipeline as streamPipeline } from 'node:stream/promises';
import { request } from 'undici';
import { create as createYoutubeDl } from 'youtube-dl-exec';

// Use the system yt-dlp binary (pre-installed at /usr/local/bin/yt-dlp)
// rather than the vendored one, since the package's postinstall may not run
// in some pnpm configurations. Falls back to PATH lookup.
const YT_DLP_BINARY = process.env.YT_DLP_PATH ?? '/usr/local/bin/yt-dlp';
const youtubeDl = createYoutubeDl(YT_DLP_BINARY);
import type { SourcePlatform } from '@remix/shared';
import { RemixError } from '../lib/errors.js';
import { probeVideo } from '../lib/ffmpeg.js';
import { uploadFile } from '../providers/storage-client.js';
import { logger } from '../lib/logger.js';

export const MAX_SOURCE_DURATION_SECONDS = 60;
export const MAX_UPLOAD_BYTES = 100 * 1024 * 1024; // 100 MB
export const ALLOWED_UPLOAD_MIMES = ['video/mp4', 'video/quicktime'] as const;

export interface IngestResult {
  storageUrl: string;
  storageKey: string;
  durationSeconds: number;
  aspectRatio: string;
  platform: SourcePlatform;
}

/**
 * Downloads a video from a supported platform URL with yt-dlp, caps length
 * at 60s, probes it, uploads the MP4 to storage, and returns the result.
 */
export async function ingestFromUrl(params: {
  url: string;
  platform: SourcePlatform;
  jobId: string;
}): Promise<IngestResult> {
  const workDir = join(tmpdir(), `remix-ingest-${params.jobId}-${randomUUID()}`);
  await mkdir(workDir, { recursive: true });
  const outputPath = join(workDir, 'source.mp4');
  try {
    if (params.platform === 'direct-mp4') {
      // Direct-MP4: skip yt-dlp and stream the file with a plain HTTP GET.
      // 60s + 100MB caps are enforced downstream in finalizeIngest via ffprobe.
      await downloadDirectMp4({ url: params.url, outputPath });
    } else {
      await youtubeDl(params.url, {
        output: outputPath,
        format: 'mp4/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',
        mergeOutputFormat: 'mp4',
        noPlaylist: true,
        // Hard cap at 60s — yt-dlp downloads in full first but ffprobe check
        // afterwards rejects longer videos. The `match-filter` flag skips
        // early when duration metadata is available.
        matchFilter: `duration<=${MAX_SOURCE_DURATION_SECONDS}`,
        quiet: true,
        noWarnings: true,
      });
    }
    return await finalizeIngest({
      inputPath: outputPath,
      platform: params.platform,
      jobId: params.jobId,
      workDir,
    });
  } catch (err) {
    await safeCleanup(workDir);
    if (err instanceof RemixError) throw err;
    logger.error('ingestFromUrl failed', { err: String(err), url: params.url });
    throw new RemixError('INGEST_FAILED', 'Failed to ingest source from URL', {
      cause: err,
      details: { url: params.url },
    });
  }
}

export interface IngestFromLocalParams {
  /** Already-downloaded MP4/MOV (e.g. the user's upload landed in S3 and we pulled it). */
  inputPath: string;
  contentType: string;
  sizeBytes: number;
  jobId: string;
}

/**
 * Validates and re-stores an uploaded file. The file is already on disk
 * (caller pulled it from the user's signed-URL S3 object).
 */
export async function ingestFromUpload(params: IngestFromLocalParams): Promise<IngestResult> {
  const workDir = join(tmpdir(), `remix-upload-${params.jobId}-${randomUUID()}`);
  await mkdir(workDir, { recursive: true });
  try {
    if (params.sizeBytes > MAX_UPLOAD_BYTES) {
      throw new RemixError('UPLOAD_TOO_LARGE', 'Upload exceeds 100MB limit', {
        details: { sizeBytes: params.sizeBytes, maxBytes: MAX_UPLOAD_BYTES },
      });
    }
    if (!ALLOWED_UPLOAD_MIMES.includes(params.contentType as (typeof ALLOWED_UPLOAD_MIMES)[number])) {
      throw new RemixError('VALIDATION_ERROR', 'Only MP4 and MOV uploads are supported', {
        details: { contentType: params.contentType },
      });
    }
    return await finalizeIngest({
      inputPath: params.inputPath,
      platform: 'upload',
      jobId: params.jobId,
      workDir,
    });
  } catch (err) {
    await safeCleanup(workDir);
    if (err instanceof RemixError) throw err;
    logger.error('ingestFromUpload failed', { err: String(err) });
    throw new RemixError('INGEST_FAILED', 'Failed to ingest uploaded file', { cause: err });
  }
}

async function finalizeIngest(params: {
  inputPath: string;
  platform: SourcePlatform;
  jobId: string;
  workDir: string;
}): Promise<IngestResult> {
  const probe = await probeVideo(params.inputPath);
  if (!probe.hasVideoStream) {
    throw new RemixError('AUDIO_ONLY_REJECTED', 'Source has no video stream');
  }
  if (probe.durationSeconds > MAX_SOURCE_DURATION_SECONDS) {
    throw new RemixError(
      'DURATION_TOO_LONG',
      `Source exceeds ${MAX_SOURCE_DURATION_SECONDS}s cap`,
      { details: { durationSeconds: probe.durationSeconds } },
    );
  }
  const fileStat = await stat(params.inputPath);
  if (fileStat.size > MAX_UPLOAD_BYTES * 3) {
    throw new RemixError('UPLOAD_TOO_LARGE', 'Downloaded file is too large');
  }

  const storageKey = `sources/${params.jobId}/source.mp4`;
  const storageUrl = await uploadFile({
    key: storageKey,
    localPath: params.inputPath,
    contentType: 'video/mp4',
  });

  await safeCleanup(params.workDir);

  return {
    storageUrl,
    storageKey,
    durationSeconds: Math.round(probe.durationSeconds),
    aspectRatio: probe.aspectRatio,
    platform: params.platform,
  };
}

/**
 * Streams a raw MP4 from an http(s) URL to local disk. Enforces the 100MB
 * byte cap during the download so we short-circuit on oversized files before
 * the full body arrives. Content-Length (when present) is validated up front.
 */
async function downloadDirectMp4(params: {
  url: string;
  outputPath: string;
}): Promise<void> {
  const res = await request(params.url, {
    maxRedirections: 5,
    headers: { 'user-agent': 'remix-ingest/1.0' },
  });
  if (res.statusCode >= 400) {
    throw new RemixError(
      'INGEST_FAILED',
      `Failed to download MP4 (HTTP ${res.statusCode})`,
      { details: { url: params.url, statusCode: res.statusCode } },
    );
  }
  const contentLengthHeader = res.headers['content-length'];
  const contentLength =
    typeof contentLengthHeader === 'string'
      ? Number(contentLengthHeader)
      : Array.isArray(contentLengthHeader)
        ? Number(contentLengthHeader[0])
        : NaN;
  if (Number.isFinite(contentLength) && contentLength > MAX_UPLOAD_BYTES) {
    throw new RemixError('UPLOAD_TOO_LARGE', 'Remote MP4 exceeds 100MB limit', {
      details: { sizeBytes: contentLength, maxBytes: MAX_UPLOAD_BYTES },
    });
  }
  await streamPipeline(res.body, createWriteStream(params.outputPath));
}

async function safeCleanup(dir: string): Promise<void> {
  try {
    await rm(dir, { recursive: true, force: true });
  } catch (err) {
    logger.warn('cleanup failed', { dir, err: String(err) });
  }
}
