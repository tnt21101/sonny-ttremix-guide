import { describe, it, expect } from 'vitest';
import type { RemixJob, SourceAnalysis, SwapSpec } from '@remix/shared';
import { buildRemixPrompt } from './build-remix-prompt.js';
import { RemixError } from '../lib/errors.js';

function makeAnalysis(overrides: Partial<SourceAnalysis> = {}): SourceAnalysis {
  return {
    character: {
      appearance: 'man in hoodie',
      ageRange: '25-35',
      vibe: 'chill',
      genderPresentation: 'masculine',
    },
    product: {
      detected: true,
      nameGuess: 'energy bar',
      type: 'food',
      brandingVisible: true,
    },
    scene: { setting: 'kitchen', lighting: 'bright', timeOfDay: 'morning' },
    blocking: { framing: 'medium', subjectPosition: 'center', cameraDistance: 'close' },
    cameraStyle: { movement: 'handheld', angle: 'eye-level', motionFeel: 'energetic' },
    actions: ['opens wrapper', 'takes bite'],
    emotionalBeats: ['curious', 'satisfied'],
    ...overrides,
  };
}

function makeJob(overrides: Partial<RemixJob> = {}): RemixJob {
  const swap: SwapSpec = {
    character: {
      mode: 'describe',
      description: 'an astronaut in full spacesuit',
      referenceImageUrl: null,
    },
    product: null,
  };
  return {
    id: 'job-1',
    userId: 'user-1',
    sourceType: 'url',
    sourceUrl: 'https://tiktok.com/@u/video/1',
    sourcePlatform: 'tiktok',
    sourceVideoStorageUrl: 'https://stub/sources/job-1/source.mp4',
    sourceDurationSeconds: 12,
    sourceAspectRatio: '9:16',
    transcript: 'These bars changed my breakfast game.',
    transcriptWords: [],
    keyframeUrls: [],
    sourceAnalysis: makeAnalysis(),
    swapSpec: swap,
    preserveOriginalAudio: true,
    captionPreset: 'clean',
    modelId: null,
    generatedVideoUrl: null,
    status: 'pending',
    errorMessage: null,
    costCents: null,
    createdAt: new Date().toISOString(),
    completedAt: null,
    ...overrides,
  };
}

describe('build-remix-prompt', () => {
  it('includes the fixed template preamble and swap character', () => {
    const { prompt, referenceVideoUrl } = buildRemixPrompt(makeJob());
    expect(prompt).toContain('Recreate this video scene exactly as shown in @Video1');
    expect(prompt).toContain('Character is now an astronaut in full spacesuit');
    expect(prompt).toContain('Preserve: script, camera movement, blocking');
    expect(prompt).toContain('Script (enforce as dialogue): These bars changed my breakfast game.');
    expect(referenceVideoUrl).toBe('https://stub/sources/job-1/source.mp4');
  });

  it('falls back to the original product when product swap is absent', () => {
    const { prompt } = buildRemixPrompt(makeJob());
    expect(prompt).toContain('Product is the original energy bar food');
  });

  it('includes scene, blocking, camera, actions, and emotional beats', () => {
    const { prompt } = buildRemixPrompt(makeJob());
    expect(prompt).toContain('Setting: kitchen');
    expect(prompt).toContain('Framing: medium');
    expect(prompt).toContain('Camera: handheld, eye-level, energetic');
    expect(prompt).toContain('Key actions: opens wrapper; takes bite');
    expect(prompt).toContain('Emotional beats: curious; satisfied');
  });

  it('uses reference-image phrasing and lists the image url when character mode is reference-image', () => {
    const job = makeJob({
      swapSpec: {
        character: {
          mode: 'reference-image',
          description: 'green alien',
          referenceImageUrl: 'https://stub/ref.jpg',
        },
        product: null,
      },
    });
    const { prompt, referenceImageUrls } = buildRemixPrompt(job);
    expect(prompt).toContain('the character shown in the attached reference image');
    expect(prompt).toContain('green alien');
    expect(referenceImageUrls).toEqual(['https://stub/ref.jpg']);
  });

  it('throws when analysis is missing', () => {
    const job = makeJob({ sourceAnalysis: null });
    expect(() => buildRemixPrompt(job)).toThrow(RemixError);
  });

  it('throws when swap spec is missing', () => {
    const job = makeJob({ swapSpec: null });
    expect(() => buildRemixPrompt(job)).toThrow(RemixError);
  });

  it('throws when describe mode has empty description', () => {
    const job = makeJob({
      swapSpec: {
        character: { mode: 'describe', description: '', referenceImageUrl: null },
        product: null,
      },
    });
    expect(() => buildRemixPrompt(job)).toThrow(RemixError);
  });

  it('handles jobs without a transcript', () => {
    const job = makeJob({ transcript: null });
    const { prompt } = buildRemixPrompt(job);
    expect(prompt).toContain('(no spoken dialogue');
  });
});
