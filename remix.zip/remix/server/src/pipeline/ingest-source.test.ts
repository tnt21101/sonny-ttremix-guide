import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { writeFile, mkdir, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import {
  ingestFromUpload,
  MAX_UPLOAD_BYTES,
  ALLOWED_UPLOAD_MIMES,
} from './ingest-source.js';
import { RemixError } from '../lib/errors.js';

vi.mock('../providers/storage-client.js', () => ({
  uploadFile: vi.fn(async (opts: { key: string }) => `https://stub/${opts.key}`),
  createSignedUploadUrl: vi.fn(),
  createSignedDownloadUrl: vi.fn(),
  publicUrlFor: vi.fn((key: string) => `https://stub/${key}`),
  extractKeyFromUrl: vi.fn(),
}));

vi.mock('../lib/ffmpeg.js', () => ({
  probeVideo: vi.fn(async () => ({
    durationSeconds: 12,
    aspectRatio: '9:16',
    width: 1080,
    height: 1920,
    hasVideoStream: true,
    hasAudioStream: true,
  })),
  extractKeyframes: vi.fn(),
  extractAudio: vi.fn(),
  muxVideoWithAudio: vi.fn(),
  burnCaptions: vi.fn(),
  aspectRatioFrom: vi.fn(() => '9:16'),
}));

describe('ingest-source (upload path)', () => {
  const tmpFiles: string[] = [];

  async function makeTempVideo(sizeBytes: number): Promise<string> {
    const dir = join(tmpdir(), `remix-test-${randomUUID()}`);
    await mkdir(dir, { recursive: true });
    const p = join(dir, 'file.mp4');
    await writeFile(p, Buffer.alloc(sizeBytes, 0));
    tmpFiles.push(dir);
    return p;
  }

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('rejects uploads exceeding 100MB', async () => {
    await expect(
      ingestFromUpload({
        inputPath: '/tmp/fake.mp4',
        contentType: 'video/mp4',
        sizeBytes: MAX_UPLOAD_BYTES + 1,
        jobId: 'job-1',
      }),
    ).rejects.toThrow(RemixError);
  });

  it('rejects non-MP4/MOV content types', async () => {
    await expect(
      ingestFromUpload({
        inputPath: '/tmp/fake.mp4',
        contentType: 'video/avi',
        sizeBytes: 1024,
        jobId: 'job-1',
      }),
    ).rejects.toThrow(RemixError);
  });

  it('accepts all allowed content types', () => {
    expect(ALLOWED_UPLOAD_MIMES).toContain('video/mp4');
    expect(ALLOWED_UPLOAD_MIMES).toContain('video/quicktime');
  });

  it('ingests a valid short upload and returns storage url + probe data', async () => {
    const path = await makeTempVideo(1024);
    const result = await ingestFromUpload({
      inputPath: path,
      contentType: 'video/mp4',
      sizeBytes: 1024,
      jobId: 'job-ok',
    });
    expect(result.platform).toBe('upload');
    expect(result.durationSeconds).toBe(12);
    expect(result.aspectRatio).toBe('9:16');
    expect(result.storageKey).toBe('sources/job-ok/source.mp4');
    expect(result.storageUrl).toContain('sources/job-ok/source.mp4');
  });

  it('rejects audio-only sources', async () => {
    const { probeVideo } = await import('../lib/ffmpeg.js');
    vi.mocked(probeVideo).mockResolvedValueOnce({
      durationSeconds: 10,
      aspectRatio: '9:16',
      width: 0,
      height: 0,
      hasVideoStream: false,
      hasAudioStream: true,
    });
    const path = await makeTempVideo(1024);
    await expect(
      ingestFromUpload({
        inputPath: path,
        contentType: 'video/mp4',
        sizeBytes: 1024,
        jobId: 'job-audio',
      }),
    ).rejects.toThrow(/no video stream/i);
  });

  it('rejects uploads that exceed the 60s duration cap', async () => {
    const { probeVideo } = await import('../lib/ffmpeg.js');
    vi.mocked(probeVideo).mockResolvedValueOnce({
      durationSeconds: 120,
      aspectRatio: '9:16',
      width: 1080,
      height: 1920,
      hasVideoStream: true,
      hasAudioStream: true,
    });
    const path = await makeTempVideo(1024);
    await expect(
      ingestFromUpload({
        inputPath: path,
        contentType: 'video/mp4',
        sizeBytes: 1024,
        jobId: 'job-long',
      }),
    ).rejects.toThrow(/60s cap/i);
  });

  afterEach(async () => {
    for (const dir of tmpFiles) {
      await rm(dir, { recursive: true, force: true });
    }
    tmpFiles.length = 0;
  });
});
