import OpenAI from 'openai';
import { createReadStream } from 'node:fs';
import type { TranscriptWord } from '@remix/shared';
import { env } from '../lib/env.js';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

const openai = new OpenAI({ apiKey: env.openaiApiKey });

export interface TranscribeResult {
  transcript: string;
  words: TranscriptWord[];
}

export async function transcribeAudio(filePath: string): Promise<TranscribeResult> {
  try {
    const response = await openai.audio.transcriptions.create({
      file: createReadStream(filePath),
      model: 'whisper-1',
      response_format: 'verbose_json',
      timestamp_granularities: ['word'],
    });
    // verbose_json payload includes text + words[{word,start,end}]
    const payload = response as unknown as {
      text?: string;
      words?: Array<{ word: string; start: number; end: number }>;
    };
    const transcript = typeof payload.text === 'string' ? payload.text : '';
    const words: TranscriptWord[] = Array.isArray(payload.words)
      ? payload.words.map((w) => ({
          word: w.word,
          start: Number(w.start),
          end: Number(w.end),
        }))
      : [];
    return { transcript, words };
  } catch (err) {
    logger.error('whisper.transcribeAudio failed', { err: String(err) });
    throw new RemixError('WHISPER_ERROR', 'Whisper transcription failed', { cause: err });
  }
}
