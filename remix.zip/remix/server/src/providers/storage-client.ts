import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { env } from '../lib/env.js';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

const s3 = new S3Client({
  region: env.awsRegion,
  credentials: {
    accessKeyId: env.awsAccessKeyId,
    secretAccessKey: env.awsSecretAccessKey,
  },
});

export interface UploadFileOptions {
  key: string;
  localPath: string;
  contentType: string;
}

export async function uploadFile({
  key,
  localPath,
  contentType,
}: UploadFileOptions): Promise<string> {
  try {
    const { size } = await stat(localPath);
    const body = createReadStream(localPath);
    await s3.send(
      new PutObjectCommand({
        Bucket: env.s3Bucket,
        Key: key,
        Body: body,
        ContentType: contentType,
        ContentLength: size,
      }),
    );
    return publicUrlFor(key);
  } catch (err) {
    logger.error('storage.uploadFile failed', { key, err: String(err) });
    throw new RemixError('STORAGE_ERROR', 'Failed to upload file to storage', {
      cause: err,
      details: { key },
    });
  }
}

export async function createSignedUploadUrl(params: {
  key: string;
  contentType: string;
  expiresSeconds?: number;
}): Promise<string> {
  const { key, contentType, expiresSeconds = 900 } = params;
  try {
    const command = new PutObjectCommand({
      Bucket: env.s3Bucket,
      Key: key,
      ContentType: contentType,
    });
    return await getSignedUrl(s3, command, { expiresIn: expiresSeconds });
  } catch (err) {
    logger.error('storage.createSignedUploadUrl failed', { key, err: String(err) });
    throw new RemixError('STORAGE_ERROR', 'Failed to create signed upload URL', {
      cause: err,
      details: { key },
    });
  }
}

export async function createSignedDownloadUrl(params: {
  key: string;
  expiresSeconds?: number;
}): Promise<string> {
  const { key, expiresSeconds = 3600 } = params;
  try {
    const command = new GetObjectCommand({ Bucket: env.s3Bucket, Key: key });
    return await getSignedUrl(s3, command, { expiresIn: expiresSeconds });
  } catch (err) {
    logger.error('storage.createSignedDownloadUrl failed', { key, err: String(err) });
    throw new RemixError('STORAGE_ERROR', 'Failed to create signed download URL', {
      cause: err,
      details: { key },
    });
  }
}

export function publicUrlFor(key: string): string {
  return `https://${env.s3Bucket}.s3.${env.awsRegion}.amazonaws.com/${key}`;
}

export function extractKeyFromUrl(url: string): string | null {
  const prefix = `https://${env.s3Bucket}.s3.${env.awsRegion}.amazonaws.com/`;
  return url.startsWith(prefix) ? url.slice(prefix.length) : null;
}
