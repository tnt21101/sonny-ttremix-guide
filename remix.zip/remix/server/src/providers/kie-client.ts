import { request } from 'undici';
import { env } from '../lib/env.js';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

export interface KieSubmitRequest {
  modelSlug: string;
  prompt: string;
  referenceVideoUrl?: string;
  referenceImageUrls?: string[];
  aspectRatio: string;
  durationSeconds: number;
  resolution?: '480p' | '720p' | '1080p';
}

export interface KieSubmitResponse {
  taskId: string;
}

export type KieStatus = 'queued' | 'running' | 'succeeded' | 'failed';

export interface KieStatusResponse {
  taskId: string;
  status: KieStatus;
  videoUrl: string | null;
  errorMessage: string | null;
}

/**
 * Submits a video generation task to KIE.ai. KIE exposes multiple model
 * slugs under a single REST surface; we pass the slug through unchanged.
 *
 * Endpoint shape (verified against https://docs.kie.ai/market/bytedance/ Apr 2026):
 *   POST /api/v1/jobs/createTask       — body { model, input: {...} }
 *   GET  /api/v1/jobs/recordInfo?taskId=...
 *
 * Input parameter names vary by model family:
 *   seedance-2:       first_frame_url, reference_image_urls, reference_video_urls
 *   seedance-1.5-pro: input_urls (image refs)
 * We pass both styles — KIE ignores unknown keys.
 */
export async function submitKieTask(params: KieSubmitRequest): Promise<KieSubmitResponse> {
  const firstImage = params.referenceImageUrls?.[0];
  const input: Record<string, unknown> = {
    prompt: params.prompt,
    aspect_ratio: params.aspectRatio,
    duration: params.durationSeconds,
    resolution: params.resolution ?? '720p',
  };
  if (firstImage) {
    input.first_frame_url = firstImage;
    input.input_urls = params.referenceImageUrls;
    input.reference_image_urls = params.referenceImageUrls;
  }
  if (params.referenceVideoUrl) {
    input.reference_video_urls = [params.referenceVideoUrl];
  }
  const body = { model: params.modelSlug, input };

  try {
    const res = await request(`${env.kieBaseUrl}/api/v1/jobs/createTask`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${env.kieApiKey}`,
      },
      body: JSON.stringify(body),
    });
    const text = await res.body.text();
    if (res.statusCode >= 400) {
      throw new RemixError('KIE_ERROR', `KIE submit failed (${res.statusCode})`, {
        details: { status: res.statusCode, response: text.slice(0, 500) },
      });
    }
    const parsed = safeJsonParse(text);
    // KIE wraps results as { code, msg, data: { taskId } } in some environments.
    const taskId =
      extractString(parsed, ['data', 'taskId']) ??
      extractString(parsed, ['taskId']) ??
      extractString(parsed, ['data', 'task_id']);
    if (!taskId) {
      throw new RemixError('KIE_ERROR', 'KIE submit returned no taskId', {
        details: { response: text.slice(0, 500) },
      });
    }
    return { taskId };
  } catch (err) {
    if (err instanceof RemixError) throw err;
    logger.error('kie.submit failed', { err: String(err) });
    throw new RemixError('KIE_ERROR', 'KIE submit request failed', { cause: err });
  }
}

export async function getKieTaskStatus(taskId: string): Promise<KieStatusResponse> {
  try {
    const res = await request(
      `${env.kieBaseUrl}/api/v1/jobs/recordInfo?taskId=${encodeURIComponent(taskId)}`,
      {
        method: 'GET',
        headers: { authorization: `Bearer ${env.kieApiKey}` },
      },
    );
    const text = await res.body.text();
    if (res.statusCode >= 400) {
      throw new RemixError('KIE_ERROR', `KIE status failed (${res.statusCode})`, {
        details: { status: res.statusCode, response: text.slice(0, 500) },
      });
    }
    const parsed = safeJsonParse(text);
    // KIE recordInfo returns: { data: { state, resultJson: string | null, failMsg, ... } }
    // where state is one of: waiting | queuing | generating | success | fail
    // and resultJson is a stringified JSON with the output urls when state=success.
    const rawState =
      extractString(parsed, ['data', 'state']) ??
      extractString(parsed, ['data', 'status']) ??
      extractString(parsed, ['status']) ??
      'queued';
    const resultJsonText = extractString(parsed, ['data', 'resultJson']);
    let videoUrl: string | null = null;
    if (resultJsonText) {
      const resultObj = safeJsonParse(resultJsonText);
      videoUrl =
        extractString(resultObj, ['resultUrls', '0']) ??
        extractString(resultObj, ['video_url']) ??
        extractString(resultObj, ['videoUrl']) ??
        extractFirstArrayString(resultObj, ['resultUrls']) ??
        extractFirstArrayString(resultObj, ['urls']);
    }
    const errorMessage =
      extractString(parsed, ['data', 'failMsg']) ??
      extractString(parsed, ['data', 'error']) ??
      extractString(parsed, ['error']) ??
      null;
    return {
      taskId,
      status: normalizeStatus(rawState),
      videoUrl,
      errorMessage,
    };
  } catch (err) {
    if (err instanceof RemixError) throw err;
    logger.error('kie.status failed', { err: String(err) });
    throw new RemixError('KIE_ERROR', 'KIE status request failed', { cause: err });
  }
}

export interface PollKieOptions {
  taskId: string;
  intervalMs?: number;
  timeoutMs?: number;
  onUpdate?: (status: KieStatusResponse) => Promise<void> | void;
}

export async function pollKieTask({
  taskId,
  intervalMs = 5_000,
  timeoutMs = 10 * 60_000,
  onUpdate,
}: PollKieOptions): Promise<KieStatusResponse> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const status = await getKieTaskStatus(taskId);
    if (onUpdate) await onUpdate(status);
    if (status.status === 'succeeded' || status.status === 'failed') {
      return status;
    }
    await sleep(intervalMs);
  }
  throw new RemixError('KIE_ERROR', 'KIE task timed out', { details: { taskId, timeoutMs } });
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function safeJsonParse(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function extractString(value: unknown, path: readonly string[]): string | null {
  let current: unknown = value;
  for (const key of path) {
    if (current && typeof current === 'object' && key in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[key];
    } else {
      return null;
    }
  }
  return typeof current === 'string' ? current : null;
}

function normalizeStatus(raw: string): KieStatus {
  const lower = raw.toLowerCase();
  if (lower.includes('success') || lower === 'completed' || lower === 'done') return 'succeeded';
  if (lower.includes('fail') || lower === 'error') return 'failed';
  if (lower === 'generating' || lower === 'running' || lower === 'processing' || lower === 'in_progress') return 'running';
  return 'queued';
}

function extractFirstArrayString(value: unknown, path: readonly string[]): string | null {
  let current: unknown = value;
  for (const key of path) {
    if (current && typeof current === 'object' && key in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[key];
    } else {
      return null;
    }
  }
  if (Array.isArray(current) && typeof current[0] === 'string') return current[0];
  return null;
}
