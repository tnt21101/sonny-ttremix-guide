import Anthropic from '@anthropic-ai/sdk';
import { readFile } from 'node:fs/promises';
import type { SourceAnalysis } from '@remix/shared';
import { env } from '../lib/env.js';
import { RemixError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

const client = new Anthropic({ apiKey: env.anthropicApiKey });

const VISION_SYSTEM_PROMPT = `You analyze a short video by examining five evenly-spaced keyframes.
Return a JSON object matching exactly this TypeScript type:

{
  "character": { "appearance": string, "ageRange": string, "vibe": string, "genderPresentation": string },
  "product": { "detected": boolean, "nameGuess": string | null, "type": string | null, "brandingVisible": boolean },
  "scene": { "setting": string, "lighting": string, "timeOfDay": string },
  "blocking": { "framing": string, "subjectPosition": string, "cameraDistance": string },
  "cameraStyle": { "movement": string, "angle": string, "motionFeel": string },
  "actions": string[],
  "emotionalBeats": string[]
}

Output the JSON only, no prose, no markdown fences.`;

export interface AnalyzeKeyframesOptions {
  keyframePaths: string[];
  transcript: string;
}

export async function analyzeKeyframes({
  keyframePaths,
  transcript,
}: AnalyzeKeyframesOptions): Promise<SourceAnalysis> {
  try {
    const images = await Promise.all(
      keyframePaths.map(async (p) => {
        const buf = await readFile(p);
        return {
          type: 'image' as const,
          source: {
            type: 'base64' as const,
            media_type: 'image/jpeg' as const,
            data: buf.toString('base64'),
          },
        };
      }),
    );

    const message = await client.messages.create({
      model: env.anthropicModel,
      max_tokens: 2000,
      system: VISION_SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: [
            ...images,
            {
              type: 'text',
              text: `Transcript of the video audio:\n${transcript || '(no speech detected)'}\n\nAnalyze the video and return the JSON.`,
            },
          ],
        },
      ],
    });

    const textBlock = message.content.find((b) => b.type === 'text');
    if (!textBlock || textBlock.type !== 'text') {
      throw new RemixError('ANTHROPIC_ERROR', 'Claude returned no text block');
    }
    return parseAnalysisJson(textBlock.text);
  } catch (err) {
    if (err instanceof RemixError) throw err;
    logger.error('anthropic.analyzeKeyframes failed', { err: String(err) });
    throw new RemixError('ANTHROPIC_ERROR', 'Claude vision call failed', { cause: err });
  }
}

function parseAnalysisJson(raw: string): SourceAnalysis {
  const trimmed = raw.trim();
  const jsonStart = trimmed.indexOf('{');
  const jsonEnd = trimmed.lastIndexOf('}');
  if (jsonStart === -1 || jsonEnd === -1) {
    throw new RemixError('ANTHROPIC_ERROR', 'Claude output had no JSON object', {
      details: { preview: trimmed.slice(0, 200) },
    });
  }
  const sliced = trimmed.slice(jsonStart, jsonEnd + 1);
  let parsed: unknown;
  try {
    parsed = JSON.parse(sliced);
  } catch (err) {
    throw new RemixError('ANTHROPIC_ERROR', 'Claude output was not valid JSON', {
      details: { preview: sliced.slice(0, 200) },
      cause: err,
    });
  }
  return coerceAnalysis(parsed);
}

function coerceAnalysis(value: unknown): SourceAnalysis {
  if (!value || typeof value !== 'object') {
    throw new RemixError('ANTHROPIC_ERROR', 'Analysis JSON not an object');
  }
  const obj = value as Record<string, unknown>;
  const character = asObject(obj.character);
  const product = asObject(obj.product);
  const scene = asObject(obj.scene);
  const blocking = asObject(obj.blocking);
  const cameraStyle = asObject(obj.cameraStyle ?? obj.camera_style);
  return {
    character: {
      appearance: asString(character.appearance),
      ageRange: asString(character.ageRange ?? character.age_range),
      vibe: asString(character.vibe),
      genderPresentation: asString(character.genderPresentation ?? character.gender_presentation),
    },
    product: {
      detected: asBool(product.detected),
      nameGuess: asStringOrNull(product.nameGuess ?? product.name_guess),
      type: asStringOrNull(product.type),
      brandingVisible: asBool(product.brandingVisible ?? product.branding_visible),
    },
    scene: {
      setting: asString(scene.setting),
      lighting: asString(scene.lighting),
      timeOfDay: asString(scene.timeOfDay ?? scene.time_of_day),
    },
    blocking: {
      framing: asString(blocking.framing),
      subjectPosition: asString(blocking.subjectPosition ?? blocking.subject_position),
      cameraDistance: asString(blocking.cameraDistance ?? blocking.camera_distance),
    },
    cameraStyle: {
      movement: asString(cameraStyle.movement),
      angle: asString(cameraStyle.angle),
      motionFeel: asString(cameraStyle.motionFeel ?? cameraStyle.motion_feel),
    },
    actions: asStringArray(obj.actions),
    emotionalBeats: asStringArray(obj.emotionalBeats ?? obj.emotional_beats),
  };
}

function asObject(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' ? (value as Record<string, unknown>) : {};
}
function asString(value: unknown): string {
  return typeof value === 'string' ? value : '';
}
function asStringOrNull(value: unknown): string | null {
  return typeof value === 'string' && value.length > 0 ? value : null;
}
function asBool(value: unknown): boolean {
  return value === true;
}
function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : [];
}
