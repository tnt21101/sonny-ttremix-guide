/**
 * Smoke test: runs ingest → analyze → generate → polish end-to-end
 * against the user-provided TikTok URL. This is the SINGLE authorized
 * paid KIE call (user explicitly authorized via smoke test request).
 *
 * Usage: cd /home/user/workspace/remix/server && pnpm tsx src/smoke-test.ts
 */
import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { join } from 'node:path';
import { pipeline as streamPipeline } from 'node:stream/promises';
import { request } from 'undici';

import type { RemixJob, SwapSpec } from '@remix/shared';

import { ingestFromUrl } from './pipeline/ingest-source.js';
import { analyzeSource } from './pipeline/analyze-source.js';
import { generateRemix } from './pipeline/generate-remix.js';
import { polishRemix } from './pipeline/polish-remix.js';
import { DEFAULT_MODEL_ID } from './lib/model-registry.js';

const TIKTOK_URL =
  'https://www.tiktok.com/@eatlevels/video/7622479380790447373?is_from_webapp=1&sender_device=pc';

const ARTIFACT_DIR = '/home/user/workspace/remix/smoke-artifacts';
const LOG_FILE = join(ARTIFACT_DIR, 'smoke-test.log');

const logLines: string[] = [];

function stamp(): string {
  return new Date().toISOString();
}

function log(message: string, extra?: Record<string, unknown>): void {
  const line = extra
    ? `[${stamp()}] ${message} ${JSON.stringify(extra)}`
    : `[${stamp()}] ${message}`;
  // eslint-disable-next-line no-console
  console.log(line);
  logLines.push(line);
}

async function flushLog(): Promise<void> {
  await writeFile(LOG_FILE, logLines.join('\n') + '\n', 'utf8');
}

async function downloadToFile(url: string, outputPath: string): Promise<void> {
  const res = await request(url);
  if (res.statusCode >= 400) {
    throw new Error(`Download failed: ${res.statusCode} for ${url}`);
  }
  await streamPipeline(res.body, createWriteStream(outputPath));
}

async function main(): Promise<void> {
  await mkdir(ARTIFACT_DIR, { recursive: true });

  const jobId = randomUUID();
  const userId = 'smoke-test-user';
  log('Smoke test starting', { jobId, userId, tiktokUrl: TIKTOK_URL });

  // ====== STAGE 1: INGEST ======
  log('Stage 1: INGEST — downloading from TikTok and uploading to S3');
  const ingestStart = Date.now();
  const ingest = await ingestFromUrl({
    url: TIKTOK_URL,
    platform: 'tiktok',
    jobId,
  });
  log('Stage 1: INGEST complete', {
    durationMs: Date.now() - ingestStart,
    storageUrl: ingest.storageUrl,
    durationSeconds: ingest.durationSeconds,
    aspectRatio: ingest.aspectRatio,
  });

  // ====== STAGE 2: ANALYZE ======
  log('Stage 2: ANALYZE — keyframes + whisper + claude visual analysis');
  const analyzeStart = Date.now();
  const analysis = await analyzeSource({
    jobId,
    sourceVideoUrl: ingest.storageUrl,
    durationSeconds: ingest.durationSeconds,
  });
  log('Stage 2: ANALYZE complete', {
    durationMs: Date.now() - analyzeStart,
    keyframeCount: analysis.keyframeUrls.length,
    transcriptChars: analysis.transcript.length,
    transcriptWordsCount: analysis.transcriptWords.length,
    detectedCharacter: analysis.analysis.character,
    detectedProduct: analysis.analysis.product,
    scene: analysis.analysis.scene,
  });

  // ====== ASSEMBLE REMIXJOB ======
  // Character swap: describe mode — swap character to a golden retriever in a
  // chef's hat. Keeps the script and scene otherwise identical.
  const swapSpec: SwapSpec = {
    character: {
      mode: 'describe',
      description:
        'a golden retriever dog wearing a white chef hat, cheerful and animated, expressive face, same clothing context as original',
      referenceImageUrl: null,
    },
    product: null,
  };

  const now = new Date().toISOString();
  const job: RemixJob = {
    id: jobId,
    userId,
    sourceType: 'url',
    sourceUrl: TIKTOK_URL,
    sourcePlatform: 'tiktok',
    sourceVideoStorageUrl: ingest.storageUrl,
    sourceDurationSeconds: ingest.durationSeconds,
    sourceAspectRatio: ingest.aspectRatio,
    transcript: analysis.transcript,
    transcriptWords: analysis.transcriptWords,
    keyframeUrls: analysis.keyframeUrls,
    sourceAnalysis: analysis.analysis,
    swapSpec,
    preserveOriginalAudio: true,
    captionPreset: 'clean',
    modelId: DEFAULT_MODEL_ID,
    generatedVideoUrl: null,
    status: 'generating',
    errorMessage: null,
    costCents: null,
    createdAt: now,
    completedAt: null,
  };

  // ====== STAGE 3: GENERATE (PAID KIE CALL — USER AUTHORIZED) ======
  log('Stage 3: GENERATE — submitting to KIE (seedance-2, the single paid call)');
  const generateStart = Date.now();
  const generate = await generateRemix({
    job,
    requestedModelId: DEFAULT_MODEL_ID,
    onProgress: async (msg) => {
      log('Stage 3: KIE progress', { msg });
    },
  });
  log('Stage 3: GENERATE complete', {
    durationMs: Date.now() - generateStart,
    modelIdUsed: generate.modelIdUsed,
    costCents: generate.costCents,
    generatedVideoUrl: generate.generatedVideoUrl,
  });

  // ====== STAGE 4: POLISH ======
  log('Stage 4: POLISH — mux original audio + burn clean captions');
  const polishStart = Date.now();
  const polish = await polishRemix({
    jobId,
    generatedVideoUrl: generate.generatedVideoUrl,
    sourceVideoUrl: ingest.storageUrl,
    transcriptWords: analysis.transcriptWords,
    captionPreset: 'clean',
    preserveOriginalAudio: true,
  });
  log('Stage 4: POLISH complete', {
    durationMs: Date.now() - polishStart,
    finalVideoUrl: polish.finalVideoUrl,
  });

  // ====== DOWNLOAD FINAL ARTIFACTS ======
  const finalPath = join(ARTIFACT_DIR, `final-${jobId}.mp4`);
  const sourcePath = join(ARTIFACT_DIR, `source-${jobId}.mp4`);
  const generatedPath = join(ARTIFACT_DIR, `generated-${jobId}.mp4`);

  log('Downloading artifacts to smoke-artifacts/');
  await downloadToFile(polish.finalVideoUrl, finalPath);
  await downloadToFile(ingest.storageUrl, sourcePath);
  await downloadToFile(generate.generatedVideoUrl, generatedPath);

  log('Smoke test SUCCESS', {
    jobId,
    finalPath,
    sourcePath,
    generatedPath,
    totalCostCents: generate.costCents,
  });

  // Write job snapshot for finalization report
  await writeFile(
    join(ARTIFACT_DIR, `job-snapshot-${jobId}.json`),
    JSON.stringify(
      {
        jobId,
        ingest,
        analysis: {
          keyframeUrls: analysis.keyframeUrls,
          transcript: analysis.transcript,
          transcriptWordCount: analysis.transcriptWords.length,
          analysis: analysis.analysis,
        },
        swapSpec,
        generate: {
          modelIdUsed: generate.modelIdUsed,
          costCents: generate.costCents,
          generatedVideoUrl: generate.generatedVideoUrl,
        },
        polish: {
          finalVideoUrl: polish.finalVideoUrl,
        },
      },
      null,
      2,
    ),
    'utf8',
  );

  await flushLog();
}

main().catch(async (err: unknown) => {
  log('Smoke test FAILED', {
    err: err instanceof Error ? err.message : String(err),
    stack: err instanceof Error ? err.stack : undefined,
  });
  await flushLog();
  // eslint-disable-next-line no-process-exit
  process.exit(1);
});
