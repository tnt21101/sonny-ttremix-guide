import ffmpeg from 'fluent-ffmpeg';
import { mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { RemixError } from './errors.js';

export interface VideoProbe {
  durationSeconds: number;
  aspectRatio: string;
  width: number;
  height: number;
  hasVideoStream: boolean;
  hasAudioStream: boolean;
}

export async function probeVideo(filePath: string): Promise<VideoProbe> {
  return new Promise<VideoProbe>((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) {
        reject(new RemixError('INGEST_FAILED', 'ffprobe failed', { cause: err }));
        return;
      }
      const videoStream = data.streams.find((s) => s.codec_type === 'video');
      const audioStream = data.streams.find((s) => s.codec_type === 'audio');
      const durationSeconds = Number(data.format.duration ?? 0);
      const width = Number(videoStream?.width ?? 0);
      const height = Number(videoStream?.height ?? 0);
      resolve({
        durationSeconds,
        aspectRatio: aspectRatioFrom(width, height),
        width,
        height,
        hasVideoStream: Boolean(videoStream),
        hasAudioStream: Boolean(audioStream),
      });
    });
  });
}

export function aspectRatioFrom(width: number, height: number): string {
  if (!width || !height) return 'unknown';
  const ratio = width / height;
  if (Math.abs(ratio - 9 / 16) < 0.05) return '9:16';
  if (Math.abs(ratio - 16 / 9) < 0.05) return '16:9';
  if (Math.abs(ratio - 1) < 0.05) return '1:1';
  return `${width}:${height}`;
}

export async function extractKeyframes(params: {
  inputPath: string;
  outputDir: string;
  count: number;
  durationSeconds: number;
}): Promise<string[]> {
  const { inputPath, outputDir, count, durationSeconds } = params;
  await mkdir(outputDir, { recursive: true });
  // evenly spaced timestamps: skip the exact ends to avoid black frames
  const offsets: string[] = [];
  for (let i = 0; i < count; i += 1) {
    const fraction = (i + 1) / (count + 1);
    offsets.push((durationSeconds * fraction).toFixed(2));
  }
  return new Promise<string[]>((resolve, reject) => {
    const filenames: string[] = [];
    ffmpeg(inputPath)
      .on('filenames', (names: string[]) => {
        for (const n of names) filenames.push(join(outputDir, n));
      })
      .on('end', () => resolve(filenames))
      .on('error', (err: Error) =>
        reject(new RemixError('ANALYZE_FAILED', 'keyframe extraction failed', { cause: err })),
      )
      .screenshots({
        count,
        timestamps: offsets,
        folder: outputDir,
        filename: 'keyframe-%i.jpg',
        size: '1024x?',
      });
  });
}

export async function extractAudio(params: {
  inputPath: string;
  outputPath: string;
}): Promise<string> {
  const { inputPath, outputPath } = params;
  return new Promise<string>((resolve, reject) => {
    ffmpeg(inputPath)
      .noVideo()
      .audioCodec('libmp3lame')
      .audioBitrate('128k')
      .format('mp3')
      .on('end', () => resolve(outputPath))
      .on('error', (err: Error) =>
        reject(new RemixError('ANALYZE_FAILED', 'audio extraction failed', { cause: err })),
      )
      .save(outputPath);
  });
}

/** Replaces the audio track on a video. Writes to outputPath. */
export async function muxVideoWithAudio(params: {
  videoPath: string;
  audioPath: string;
  outputPath: string;
}): Promise<string> {
  const { videoPath, audioPath, outputPath } = params;
  return new Promise<string>((resolve, reject) => {
    ffmpeg()
      .input(videoPath)
      .input(audioPath)
      .outputOptions([
        '-map 0:v:0',
        '-map 1:a:0',
        '-c:v copy',
        '-c:a aac',
        '-shortest',
      ])
      .on('end', () => resolve(outputPath))
      .on('error', (err: Error) =>
        reject(new RemixError('POLISH_FAILED', 'mux failed', { cause: err })),
      )
      .save(outputPath);
  });
}

/** Burns an SRT subtitle track into a video. */
export async function burnCaptions(params: {
  videoPath: string;
  srtPath: string;
  outputPath: string;
}): Promise<string> {
  const { videoPath, srtPath, outputPath } = params;
  // ffmpeg subtitle filter needs the path escaped for its mini-DSL
  const escapedSrt = srtPath.replace(/:/g, '\\:').replace(/'/g, "\\'");
  return new Promise<string>((resolve, reject) => {
    ffmpeg(videoPath)
      .outputOptions([`-vf subtitles=${escapedSrt}`, '-c:a copy'])
      .on('end', () => resolve(outputPath))
      .on('error', (err: Error) =>
        reject(new RemixError('POLISH_FAILED', 'caption burn failed', { cause: err })),
      )
      .save(outputPath);
  });
}
