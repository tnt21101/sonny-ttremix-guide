import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle, type NeonDatabase } from 'drizzle-orm/neon-serverless';
import { sql } from 'drizzle-orm';
import * as schema from '@remix/db';
import ws from 'ws';
import { env } from './env.js';

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: env.databaseUrl });

export type DbClient = NeonDatabase<typeof schema>;

export const db: DbClient = drizzle(pool, { schema });

/**
 * Runs `fn` inside a transaction with `app.current_user_id` set to the given
 * user id. RLS policies read this session variable. The setting is scoped to
 * the transaction (is_local=true) so it doesn't leak between requests.
 *
 * The userId must be a UUID — it is authenticated upstream and passed into
 * set_config via a parameter binding, not a literal.
 */
export async function withUserContext<T>(
  userId: string,
  fn: (tx: DbClient) => Promise<T>,
): Promise<T> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`SELECT set_config('app.current_user_id', ${userId}, true)`);
    return fn(tx as unknown as DbClient);
  });
}
