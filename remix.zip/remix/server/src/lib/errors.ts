export type ErrorCode =
  | 'VALIDATION_ERROR'
  | 'NOT_FOUND'
  | 'UNAUTHORIZED'
  | 'FORBIDDEN'
  | 'PLATFORM_UNSUPPORTED'
  | 'UPLOAD_TOO_LARGE'
  | 'DURATION_TOO_LONG'
  | 'AUDIO_ONLY_REJECTED'
  | 'INGEST_FAILED'
  | 'ANALYZE_FAILED'
  | 'GENERATE_FAILED'
  | 'POLISH_FAILED'
  | 'KIE_ERROR'
  | 'ANTHROPIC_ERROR'
  | 'WHISPER_ERROR'
  | 'STORAGE_ERROR'
  | 'DATABASE_ERROR'
  | 'INTERNAL_ERROR';

export class RemixError extends Error {
  public readonly code: ErrorCode;
  public readonly statusCode: number;
  public readonly details: Record<string, unknown> | undefined;

  public constructor(
    code: ErrorCode,
    message: string,
    options: {
      statusCode?: number;
      details?: Record<string, unknown>;
      cause?: unknown;
    } = {},
  ) {
    super(message);
    this.name = 'RemixError';
    this.code = code;
    this.statusCode = options.statusCode ?? statusCodeForCode(code);
    this.details = options.details;
    if (options.cause !== undefined) {
      (this as Error & { cause?: unknown }).cause = options.cause;
    }
  }

  public toJSON(): { error: string; code: ErrorCode; details?: Record<string, unknown> } {
    return {
      error: this.message,
      code: this.code,
      ...(this.details ? { details: this.details } : {}),
    };
  }
}

function statusCodeForCode(code: ErrorCode): number {
  switch (code) {
    case 'VALIDATION_ERROR':
    case 'UPLOAD_TOO_LARGE':
    case 'DURATION_TOO_LONG':
    case 'AUDIO_ONLY_REJECTED':
    case 'PLATFORM_UNSUPPORTED':
      return 400;
    case 'UNAUTHORIZED':
      return 401;
    case 'FORBIDDEN':
      return 403;
    case 'NOT_FOUND':
      return 404;
    default:
      return 500;
  }
}

export function isRemixError(err: unknown): err is RemixError {
  return err instanceof RemixError;
}
