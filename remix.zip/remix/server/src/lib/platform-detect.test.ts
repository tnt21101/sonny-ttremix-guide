import { describe, it, expect } from 'vitest';
import { detectPlatform } from './platform-detect.js';
import { RemixError } from './errors.js';

describe('platform-detect', () => {
  it('detects TikTok hosts', () => {
    expect(detectPlatform('https://www.tiktok.com/@user/video/123')).toBe('tiktok');
    expect(detectPlatform('https://vm.tiktok.com/abc')).toBe('tiktok');
  });

  it('detects YouTube and youtu.be', () => {
    expect(detectPlatform('https://www.youtube.com/shorts/abc')).toBe('youtube');
    expect(detectPlatform('https://youtu.be/abc')).toBe('youtube');
  });

  it('detects X / Twitter', () => {
    expect(detectPlatform('https://x.com/user/status/123')).toBe('x');
    expect(detectPlatform('https://twitter.com/user/status/123')).toBe('x');
  });

  it('detects Facebook video hosts', () => {
    expect(detectPlatform('https://www.facebook.com/reel/123')).toBe('facebook');
    expect(detectPlatform('https://fb.watch/abc123/')).toBe('facebook');
  });

  it('detects direct .mp4 URLs on arbitrary hosts', () => {
    expect(detectPlatform('https://example.com/path/video.mp4')).toBe('direct-mp4');
    expect(detectPlatform('https://cdn.site.com/clip.MP4?token=x')).toBe('direct-mp4');
  });

  it('rejects Instagram (now unsupported)', () => {
    expect(() => detectPlatform('https://www.instagram.com/reel/abc/')).toThrow(RemixError);
  });

  it('rejects unsupported platforms', () => {
    expect(() => detectPlatform('https://example.com/video')).toThrow(RemixError);
  });

  it('rejects non-http(s) protocols', () => {
    expect(() => detectPlatform('ftp://example.com/video.mp4')).toThrow(RemixError);
  });

  it('rejects malformed URLs', () => {
    expect(() => detectPlatform('not a url')).toThrow(RemixError);
  });
});
