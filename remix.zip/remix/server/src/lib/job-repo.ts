import { eq, desc } from 'drizzle-orm';
import { remixJobs, users } from '@remix/db';
import type {
  RemixJob,
  RemixJobStatus,
  SourceAnalysis,
  SourcePlatform,
  SourceType,
  SwapSpec,
  TranscriptWord,
  CaptionPreset,
} from '@remix/shared';
import { db, withUserContext } from './db.js';
import { RemixError } from './errors.js';

type DbJobRow = typeof remixJobs.$inferSelect;

function toJob(row: DbJobRow): RemixJob {
  return {
    id: row.id,
    userId: row.userId,
    sourceType: row.sourceType as SourceType,
    sourceUrl: row.sourceUrl,
    sourcePlatform: row.sourcePlatform as SourcePlatform,
    sourceVideoStorageUrl: row.sourceVideoStorageUrl,
    sourceDurationSeconds: row.sourceDurationSeconds,
    sourceAspectRatio: row.sourceAspectRatio,
    transcript: row.transcript,
    transcriptWords: (row.transcriptWords as TranscriptWord[] | null) ?? null,
    keyframeUrls: (row.keyframeUrls as string[] | null) ?? null,
    sourceAnalysis: (row.sourceAnalysis as SourceAnalysis | null) ?? null,
    swapSpec: (row.swapSpec as SwapSpec | null) ?? null,
    preserveOriginalAudio: row.preserveOriginalAudio,
    captionPreset: (row.captionPreset as CaptionPreset | null) ?? null,
    modelId: row.modelId,
    generatedVideoUrl: row.generatedVideoUrl,
    status: row.status as RemixJobStatus,
    errorMessage: row.errorMessage,
    costCents: row.costCents,
    createdAt: row.createdAt.toISOString(),
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
  };
}

export interface CreateJobInput {
  userId: string;
  sourceType: SourceType;
  sourcePlatform: SourcePlatform;
  sourceUrl: string | null;
  sourceVideoStorageUrl: string | null;
}

export async function createJob(input: CreateJobInput): Promise<RemixJob> {
  return withUserContext(input.userId, async (tx) => {
    const [row] = await tx
      .insert(remixJobs)
      .values({
        userId: input.userId,
        sourceType: input.sourceType,
        sourcePlatform: input.sourcePlatform,
        sourceUrl: input.sourceUrl,
        sourceVideoStorageUrl: input.sourceVideoStorageUrl,
        status: 'pending',
      })
      .returning();
    if (!row) throw new RemixError('DATABASE_ERROR', 'Failed to insert remix job');
    return toJob(row);
  });
}

export async function getJob(userId: string, jobId: string): Promise<RemixJob | null> {
  return withUserContext(userId, async (tx) => {
    const rows = await tx.select().from(remixJobs).where(eq(remixJobs.id, jobId)).limit(1);
    const row = rows[0];
    return row ? toJob(row) : null;
  });
}

/** Pipeline workers fetch jobs without an auth session. RLS does not apply. */
export async function getJobInternal(jobId: string): Promise<RemixJob | null> {
  const rows = await db.select().from(remixJobs).where(eq(remixJobs.id, jobId)).limit(1);
  const row = rows[0];
  return row ? toJob(row) : null;
}

export async function listJobsForUser(userId: string): Promise<RemixJob[]> {
  return withUserContext(userId, async (tx) => {
    const rows = await tx
      .select()
      .from(remixJobs)
      .where(eq(remixJobs.userId, userId))
      .orderBy(desc(remixJobs.createdAt));
    return rows.map(toJob);
  });
}

export interface UpdateJobPatch {
  status?: RemixJobStatus;
  sourceDurationSeconds?: number;
  sourceAspectRatio?: string;
  sourceVideoStorageUrl?: string;
  transcript?: string;
  transcriptWords?: TranscriptWord[];
  keyframeUrls?: string[];
  sourceAnalysis?: SourceAnalysis;
  swapSpec?: SwapSpec;
  preserveOriginalAudio?: boolean;
  captionPreset?: CaptionPreset;
  modelId?: string;
  generatedVideoUrl?: string;
  errorMessage?: string | null;
  costCents?: number;
  completedAt?: Date;
}

/** Updates used by pipeline workers (no RLS context). */
export async function updateJobInternal(jobId: string, patch: UpdateJobPatch): Promise<RemixJob> {
  const [row] = await db
    .update(remixJobs)
    .set(patch)
    .where(eq(remixJobs.id, jobId))
    .returning();
  if (!row) throw new RemixError('NOT_FOUND', 'Remix job not found');
  return toJob(row);
}

/** Updates scoped to the authenticated user (for user-editable fields). */
export async function updateJobForUser(
  userId: string,
  jobId: string,
  patch: UpdateJobPatch,
): Promise<RemixJob> {
  return withUserContext(userId, async (tx) => {
    const [row] = await tx
      .update(remixJobs)
      .set(patch)
      .where(eq(remixJobs.id, jobId))
      .returning();
    if (!row) throw new RemixError('NOT_FOUND', 'Remix job not found');
    return toJob(row);
  });
}

/** Upsert the users row for a Clerk user on first request. Returns the internal uuid. */
export async function upsertUser(params: {
  externalId: string;
  email: string;
}): Promise<{ id: string; email: string }> {
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.externalId, params.externalId))
    .limit(1);
  if (existing[0]) {
    return { id: existing[0].id, email: existing[0].email };
  }
  const [row] = await db
    .insert(users)
    .values({ externalId: params.externalId, email: params.email })
    .returning();
  if (!row) throw new RemixError('DATABASE_ERROR', 'Failed to upsert user');
  return { id: row.id, email: row.email };
}
