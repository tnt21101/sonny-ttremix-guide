import 'dotenv/config';

function required(name: string): string {
  const value = process.env[name];
  if (!value || value.trim().length === 0) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

function optional(name: string, fallback: string): string {
  const value = process.env[name];
  return value && value.trim().length > 0 ? value : fallback;
}

export const env = {
  port: Number.parseInt(optional('PORT', '3005'), 10),
  nodeEnv: optional('NODE_ENV', 'development'),
  clientOrigin: optional('CLIENT_ORIGIN', 'http://localhost:5173'),

  databaseUrl: required('DATABASE_URL'),

  clerkPublishableKey: required('CLERK_PUBLISHABLE_KEY'),
  clerkSecretKey: required('CLERK_SECRET_KEY'),

  redisUrl: optional('REDIS_URL', 'redis://localhost:6379'),

  anthropicApiKey: required('ANTHROPIC_API_KEY'),
  anthropicModel: optional('ANTHROPIC_MODEL', 'claude-sonnet-4-5-20250929'),

  openaiApiKey: required('OPENAI_API_KEY'),

  kieApiKey: required('KIE_API_KEY'),
  kieBaseUrl: optional('KIE_BASE_URL', 'https://api.kie.ai'),

  awsAccessKeyId: required('AWS_ACCESS_KEY_ID'),
  awsSecretAccessKey: required('AWS_SECRET_ACCESS_KEY'),
  awsRegion: optional('AWS_REGION', 'us-east-1'),
  s3Bucket: required('S3_BUCKET'),
} as const;
