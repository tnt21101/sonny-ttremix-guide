import type { SourcePlatform } from '@remix/shared';
import { RemixError } from './errors.js';

interface PlatformRule {
  platform: SourcePlatform;
  hostPatterns: RegExp[];
}

const RULES: readonly PlatformRule[] = [
  { platform: 'tiktok', hostPatterns: [/(^|\.)tiktok\.com$/i, /(^|\.)vm\.tiktok\.com$/i] },
  {
    platform: 'youtube',
    hostPatterns: [/(^|\.)youtube\.com$/i, /(^|\.)youtu\.be$/i],
  },
  { platform: 'x', hostPatterns: [/(^|\.)twitter\.com$/i, /(^|\.)x\.com$/i] },
  {
    platform: 'facebook',
    hostPatterns: [
      /(^|\.)facebook\.com$/i,
      /(^|\.)fb\.watch$/i,
      /(^|\.)fb\.com$/i,
    ],
  },
];

/**
 * Returns true if the URL's path ends in .mp4 (case-insensitive).
 * Query strings and fragments are ignored.
 */
function isDirectMp4Url(parsed: URL): boolean {
  return /\.mp4$/i.test(parsed.pathname);
}

export function detectPlatform(urlString: string): SourcePlatform {
  let parsed: URL;
  try {
    parsed = new URL(urlString);
  } catch {
    throw new RemixError('VALIDATION_ERROR', 'Invalid source URL', {
      details: { urlString },
    });
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new RemixError('VALIDATION_ERROR', 'URL must be http(s)', {
      details: { urlString },
    });
  }
  const host = parsed.hostname;
  for (const rule of RULES) {
    if (rule.hostPatterns.some((pattern) => pattern.test(host))) {
      return rule.platform;
    }
  }
  // Fallback: any http(s) URL that looks like a direct MP4 file is accepted.
  if (isDirectMp4Url(parsed)) {
    return 'direct-mp4';
  }
  throw new RemixError('PLATFORM_UNSUPPORTED', `Unsupported platform: ${host}`, {
    details: { host, urlString },
  });
}
