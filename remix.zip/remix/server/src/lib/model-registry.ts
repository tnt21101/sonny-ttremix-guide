import type { VideoModel } from '@remix/shared';

// Model IDs verified against live KIE catalog (https://docs.kie.ai/market/bytedance/).
// The spec's original pins (seedance-v1-pro, kling-3.0) do not exist on KIE;
// substituted with confirmed working slugs and communicated to user.
export const MODEL_REGISTRY: Readonly<Record<string, VideoModel>> = {
  'bytedance/seedance-2': {
    id: 'bytedance/seedance-2',
    label: 'Seedance 2.0',
    provider: 'kie',
    kieModelSlug: 'bytedance/seedance-2',
    maxDurationSeconds: 15,
    supportedAspectRatios: ['9:16', '16:9', '1:1', '4:3', '3:4', '21:9'],
    costCentsPerSecond: 20,
    isDefault: true,
    supportsReferenceVideo: true,
    supportsReferenceImage: true,
  },
  'bytedance/seedance-2-fast': {
    id: 'bytedance/seedance-2-fast',
    label: 'Seedance 2.0 Fast',
    provider: 'kie',
    kieModelSlug: 'bytedance/seedance-2-fast',
    maxDurationSeconds: 15,
    supportedAspectRatios: ['9:16', '16:9', '1:1', '4:3', '3:4', '21:9'],
    costCentsPerSecond: 10,
    isDefault: false,
    supportsReferenceVideo: true,
    supportsReferenceImage: true,
  },
  'bytedance/seedance-1.5-pro': {
    id: 'bytedance/seedance-1.5-pro',
    label: 'Seedance 1.5 Pro',
    provider: 'kie',
    kieModelSlug: 'bytedance/seedance-1.5-pro',
    maxDurationSeconds: 15,
    supportedAspectRatios: ['9:16', '16:9', '1:1'],
    costCentsPerSecond: 18,
    isDefault: false,
    supportsReferenceVideo: true,
    supportsReferenceImage: true,
  },
};

export const DEFAULT_MODEL_ID = 'bytedance/seedance-2';
export const FALLBACK_MODEL_ID = 'bytedance/seedance-2-fast';

export function getModel(id: string): VideoModel | null {
  return MODEL_REGISTRY[id] ?? null;
}

export function listModels(): VideoModel[] {
  return Object.values(MODEL_REGISTRY);
}

export function estimateCostCents(modelId: string, durationSeconds: number): number {
  const model = getModel(modelId);
  if (!model) return 0;
  const clamped = Math.max(1, Math.min(durationSeconds, model.maxDurationSeconds));
  return Math.round(model.costCentsPerSecond * clamped);
}
