import { describe, it, expect } from 'vitest';
import {
  MODEL_REGISTRY,
  getModel,
  listModels,
  estimateCostCents,
  DEFAULT_MODEL_ID,
  FALLBACK_MODEL_ID,
} from './model-registry.js';

describe('model-registry', () => {
  it('exposes Seedance 2, Seedance 2 Fast, and Seedance 1.5 Pro', () => {
    expect(Object.keys(MODEL_REGISTRY).sort()).toEqual(
      ['bytedance/seedance-2', 'bytedance/seedance-2-fast', 'bytedance/seedance-1.5-pro'].sort(),
    );
  });

  it('Seedance 2 is the default model and matches DEFAULT_MODEL_ID', () => {
    const seedance = getModel('bytedance/seedance-2');
    expect(seedance?.isDefault).toBe(true);
    expect(DEFAULT_MODEL_ID).toBe('bytedance/seedance-2');
  });

  it('Seedance 2 Fast is the fallback', () => {
    expect(FALLBACK_MODEL_ID).toBe('bytedance/seedance-2-fast');
    expect(getModel(FALLBACK_MODEL_ID)).toBeTruthy();
  });

  it('listModels returns all three entries', () => {
    expect(listModels()).toHaveLength(3);
  });

  it('getModel returns null for unknown id', () => {
    expect(getModel('nonexistent')).toBeNull();
  });

  it('estimateCostCents scales by duration', () => {
    const tenSec = estimateCostCents('bytedance/seedance-2', 10);
    const fiveSec = estimateCostCents('bytedance/seedance-2', 5);
    expect(tenSec).toBe(200);
    expect(fiveSec).toBe(100);
  });

  it('estimateCostCents caps at max duration per model', () => {
    const seedanceMax = estimateCostCents('bytedance/seedance-2', 999);
    // Seedance max is 15s at 20c/s = 300c
    expect(seedanceMax).toBe(300);
  });

  it('estimateCostCents returns 0 for unknown model', () => {
    expect(estimateCostCents('nope', 5)).toBe(0);
  });

  it('every model supports at least one aspect ratio', () => {
    for (const model of listModels()) {
      expect(model.supportedAspectRatios.length).toBeGreaterThan(0);
    }
  });
});
