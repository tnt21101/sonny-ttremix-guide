import { Queue, QueueEvents } from 'bullmq';
import { Redis } from 'ioredis';
import { QUEUE_NAMES } from '@remix/shared';
import type {
  IngestJobData,
  AnalyzeJobData,
  GenerateJobData,
  PolishJobData,
} from '@remix/shared';
import { env } from './env.js';

export const redis = new Redis(env.redisUrl, {
  maxRetriesPerRequest: null,
});

const defaultJobOptions = {
  attempts: 3,
  backoff: { type: 'exponential' as const, delay: 2000 },
  removeOnComplete: { age: 3600, count: 500 },
  removeOnFail: { age: 24 * 3600 },
};

export const ingestQueue = new Queue<IngestJobData>(QUEUE_NAMES.INGEST, {
  connection: redis,
  defaultJobOptions,
});

export const analyzeQueue = new Queue<AnalyzeJobData>(QUEUE_NAMES.ANALYZE, {
  connection: redis,
  defaultJobOptions,
});

export const generateQueue = new Queue<GenerateJobData>(QUEUE_NAMES.GENERATE, {
  connection: redis,
  defaultJobOptions: { ...defaultJobOptions, attempts: 1 }, // paid API — no auto-retry
});

export const polishQueue = new Queue<PolishJobData>(QUEUE_NAMES.POLISH, {
  connection: redis,
  defaultJobOptions,
});

export const ingestQueueEvents = new QueueEvents(QUEUE_NAMES.INGEST, { connection: redis });
export const analyzeQueueEvents = new QueueEvents(QUEUE_NAMES.ANALYZE, { connection: redis });
export const generateQueueEvents = new QueueEvents(QUEUE_NAMES.GENERATE, { connection: redis });
export const polishQueueEvents = new QueueEvents(QUEUE_NAMES.POLISH, { connection: redis });
