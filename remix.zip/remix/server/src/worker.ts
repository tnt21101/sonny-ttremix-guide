import { startWorkers } from './pipeline/workers.js';
import { logger } from './lib/logger.js';

const { close } = startWorkers();

logger.info('workers.started', {});

async function shutdown(signal: string): Promise<void> {
  logger.info('workers.shutdown', { signal });
  await close();
  process.exit(0);
}

process.on('SIGINT', () => {
  void shutdown('SIGINT');
});
process.on('SIGTERM', () => {
  void shutdown('SIGTERM');
});
