import express, { type Express } from 'express';
import cors from 'cors';
import { env } from './lib/env.js';
import { clerkAuth } from './middleware/auth.js';
import { errorHandler } from './middleware/error-handler.js';
import { authRouter } from './routes/auth.js';
import { remixRouter } from './routes/remix.js';
import { uploadRouter } from './routes/upload.js';
import { recipesRouter } from './routes/recipes.js';
import { listModels } from './lib/model-registry.js';

export function createApp(): Express {
  const app = express();
  app.use(
    cors({
      origin: env.clientOrigin,
      credentials: true,
    }),
  );
  app.use(express.json({ limit: '2mb' }));
  app.use(clerkAuth);

  app.get('/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/models', (_req, res) => {
    res.json({ models: listModels() });
  });

  app.use('/auth', authRouter);
  app.use('/remix', remixRouter);
  app.use('/upload', uploadRouter);
  app.use('/recipes', recipesRouter);

  app.use(errorHandler);
  return app;
}
