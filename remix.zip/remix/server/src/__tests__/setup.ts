/**
 * Vitest setup — populate env with test placeholders so module-level env
 * checks don't throw when importing production modules in tests. Real
 * integration tests live outside this suite.
 */
process.env.DATABASE_URL ??= 'postgresql://test:test@localhost:5432/test';
process.env.CLERK_PUBLISHABLE_KEY ??= 'pk_test_placeholder';
process.env.CLERK_SECRET_KEY ??= 'sk_test_placeholder';
process.env.REDIS_URL ??= 'redis://localhost:6379';
process.env.ANTHROPIC_API_KEY ??= 'test-anthropic';
process.env.OPENAI_API_KEY ??= 'test-openai';
process.env.KIE_API_KEY ??= 'test-kie';
process.env.AWS_ACCESS_KEY_ID ??= 'test-aws-key';
process.env.AWS_SECRET_ACCESS_KEY ??= 'test-aws-secret';
process.env.AWS_REGION ??= 'us-east-1';
process.env.S3_BUCKET ??= 'test-bucket';
