import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/**/*.test.ts'],
    setupFiles: ['./src/__tests__/setup.ts'],
  },
  resolve: {
    alias: {
      '@remix/shared': new URL('../shared/src/index.ts', import.meta.url).pathname,
      '@remix/db': new URL('../db/src/index.ts', import.meta.url).pathname,
    },
  },
});
