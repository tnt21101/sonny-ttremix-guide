# Remix — Local Setup

Run the video remix app on your machine in 5 minutes.

## 1. Prerequisites

Install these if you don't have them. (Mac: `brew install <pkg>`. Linux: `apt install`.)

| Tool | Version | Mac install |
|---|---|---|
| Node.js | 20.x | `brew install node@20` |
| pnpm | 10.x | `npm install -g pnpm` |
| Redis | 7.x | `brew install redis` |
| ffmpeg | 7.x | `brew install ffmpeg` |
| yt-dlp | latest | `brew install yt-dlp` |

Verify:
```bash
node --version    # v20.x
pnpm --version    # 10.x
redis-cli ping    # PONG (start with `brew services start redis` if not)
ffmpeg -version   # 7.x
yt-dlp --version  # a date string
```

## 2. Unzip and install

```bash
unzip remix.zip
cd remix
pnpm install          # ~1 min
```

The `.env` file is already included with all credentials (Clerk, Anthropic, OpenAI, KIE, AWS S3, Neon DB, Redis) from our session. You don't need to configure anything.

## 3. Start Redis (if not already running)

```bash
# Mac (brew service):
brew services start redis

# OR one-shot in a terminal:
redis-server
```

Confirm: `redis-cli ping` → `PONG`.

## 4. Boot the three app processes

Open **three terminals** in the `remix/` folder:

### Terminal 1 — API server (port 3005)
```bash
pnpm --filter @remix/server dev
```
Wait for `server.listening port: 3005`.

### Terminal 2 — BullMQ worker
```bash
pnpm --filter @remix/server worker
```
Wait for `workers.started`.

### Terminal 3 — Vite client (port 5173)
```bash
pnpm --filter @remix/client dev
```
Wait for `VITE v5.x ready`.

## 5. Open the app

**[http://localhost:5173](http://localhost:5173)**

Sign in with any email (Clerk sends a magic code). Then on the dashboard:

1. Click **New Remix**
2. Paste a TikTok URL, e.g.: `https://www.tiktok.com/@eatlevels/video/7622479380790447373`
3. Wait ~20s for **ingest + analyze** to complete (free stages)
4. Fill the **character describe** field with something like: `a golden retriever wearing a chef hat`
5. Click **Generate** — fires KIE seedance-2, ~7 min, costs ~$1.20 for a 6s clip
6. **Polish** runs automatically after; final MP4 has original audio + captions
7. **Download** button appears

## Troubleshooting

**Port in use:** `lsof -ti:3005 | xargs kill` (or 5173 / 6379)

**Vite can't proxy to server:** make sure Terminal 1 is still running and says `port: 3005`.

**"Missing env var":** the server loads `.env` from its own folder via a symlink. If that broke in the unzip, run: `cd remix && ln -sf $(pwd)/.env server/.env`.

**BullMQ connection refused:** Redis isn't running. `redis-cli ping` must return `PONG`.

**yt-dlp path wrong:** the code hardcodes `/usr/local/bin/yt-dlp`. On Apple Silicon, brew installs to `/opt/homebrew/bin/yt-dlp`. Either symlink (`sudo ln -s /opt/homebrew/bin/yt-dlp /usr/local/bin/yt-dlp`) or edit `server/src/pipeline/ingest-source.ts` line with `create('/usr/local/bin/yt-dlp')` to match your path.

## What each process does

- **API server (3005):** Express + Clerk auth. Accepts job creation, enqueues work, serves status.
- **Worker:** BullMQ consumer. Runs 4 queues in order: `ingest → analyze → generate → polish`. This is where yt-dlp, ffmpeg, Whisper, Claude, and KIE actually run.
- **Vite client (5173):** React UI. Proxies `/api/*` → server on 3005.

## Paid API guard

Only the **Generate** button fires KIE (paid). Ingest, analyze, and polish are free. The worker's `generate` queue is configured with `attempts: 1` so failed jobs do not auto-retry and re-bill.

## Stop everything

- Hit `Ctrl+C` in each terminal
- `brew services stop redis` (optional)
