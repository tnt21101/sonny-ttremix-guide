-- Row-Level Security policies. The server connects with the owner role
-- (which bypasses RLS when FORCE is not set) and sets `app.current_user_id`
-- in transactions for user-scoped queries via withUserContext. Pipeline
-- workers run as trusted system code without a user context. These policies
-- act as defense-in-depth if a non-owner ever connects directly.
-- SPLIT
ALTER TABLE users ENABLE ROW LEVEL SECURITY
-- Users table is managed by the server (auth mapping). Owner bypasses RLS
-- so the bootstrap upsert on first Clerk sign-in succeeds. Policies below
-- still apply to any non-owner connection.
-- SPLIT
DROP POLICY IF EXISTS users_self_select ON users
-- SPLIT
CREATE POLICY users_self_select ON users
  FOR SELECT
  USING (id::text = current_setting('app.current_user_id', true))
-- SPLIT
DROP POLICY IF EXISTS users_self_insert ON users
-- SPLIT
CREATE POLICY users_self_insert ON users
  FOR INSERT
  WITH CHECK (id::text = current_setting('app.current_user_id', true))
-- SPLIT
DROP POLICY IF EXISTS users_self_update ON users
-- SPLIT
CREATE POLICY users_self_update ON users
  FOR UPDATE
  USING (id::text = current_setting('app.current_user_id', true))
  WITH CHECK (id::text = current_setting('app.current_user_id', true))
-- SPLIT
ALTER TABLE remix_jobs ENABLE ROW LEVEL SECURITY
-- SPLIT
DROP POLICY IF EXISTS remix_jobs_owner_all ON remix_jobs
-- SPLIT
CREATE POLICY remix_jobs_owner_all ON remix_jobs
  FOR ALL
  USING (user_id::text = current_setting('app.current_user_id', true))
  WITH CHECK (user_id::text = current_setting('app.current_user_id', true))
-- SPLIT
ALTER TABLE remix_recipes ENABLE ROW LEVEL SECURITY
-- SPLIT
DROP POLICY IF EXISTS remix_recipes_owner_all ON remix_recipes
-- SPLIT
CREATE POLICY remix_recipes_owner_all ON remix_recipes
  FOR ALL
  USING (user_id::text = current_setting('app.current_user_id', true))
  WITH CHECK (user_id::text = current_setting('app.current_user_id', true))
-- SPLIT
ALTER TABLE remix_batch_runs ENABLE ROW LEVEL SECURITY
-- SPLIT
DROP POLICY IF EXISTS remix_batch_runs_owner_all ON remix_batch_runs
-- SPLIT
CREATE POLICY remix_batch_runs_owner_all ON remix_batch_runs
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM remix_recipes r
      WHERE r.id = remix_batch_runs.recipe_id
        AND r.user_id::text = current_setting('app.current_user_id', true)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM remix_recipes r
      WHERE r.id = remix_batch_runs.recipe_id
        AND r.user_id::text = current_setting('app.current_user_id', true)
    )
  )
