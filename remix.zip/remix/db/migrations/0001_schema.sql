-- SPLIT
CREATE EXTENSION IF NOT EXISTS "pgcrypto"
-- SPLIT
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text NOT NULL UNIQUE,
  email text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
)
-- SPLIT
CREATE TABLE IF NOT EXISTS remix_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_type text NOT NULL,
  source_url text,
  source_platform text NOT NULL,
  source_video_storage_url text,
  source_duration_seconds integer,
  source_aspect_ratio text,
  transcript text,
  transcript_words jsonb,
  keyframe_urls jsonb,
  source_analysis jsonb,
  swap_spec jsonb,
  preserve_original_audio boolean NOT NULL DEFAULT true,
  caption_preset text,
  model_id text,
  generated_video_url text,
  status text NOT NULL DEFAULT 'pending',
  error_message text,
  cost_cents integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
)
-- SPLIT
CREATE INDEX IF NOT EXISTS idx_remix_jobs_user_id ON remix_jobs(user_id)
-- SPLIT
CREATE INDEX IF NOT EXISTS idx_remix_jobs_status ON remix_jobs(status)
-- SPLIT
CREATE TABLE IF NOT EXISTS remix_recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_job_id uuid NOT NULL REFERENCES remix_jobs(id) ON DELETE CASCADE,
  recipe_name text NOT NULL,
  preserve_fields jsonb,
  swap_template jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
)
-- SPLIT
CREATE INDEX IF NOT EXISTS idx_remix_recipes_user_id ON remix_recipes(user_id)
-- SPLIT
CREATE TABLE IF NOT EXISTS remix_batch_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id uuid NOT NULL REFERENCES remix_recipes(id) ON DELETE CASCADE,
  variants jsonb,
  job_ids jsonb,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
)
-- SPLIT
CREATE INDEX IF NOT EXISTS idx_remix_batch_runs_recipe_id ON remix_batch_runs(recipe_id)
