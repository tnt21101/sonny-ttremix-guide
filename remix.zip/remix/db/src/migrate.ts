/**
 * Applies schema DDL + RLS in one step.
 *
 * We use neon's HTTP driver with raw SQL rather than drizzle-kit's migrator
 * because we want a single atomic path: create tables, then attach RLS.
 * If anything fails the whole thing rolls back.
 */
import { config as loadEnv } from 'dotenv';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

neonConfig.webSocketConstructor = ws;
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
// Load .env from monorepo root (two dirs up from db/src)
loadEnv({ path: join(here, '../../.env') });

async function main(): Promise<void> {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error('DATABASE_URL must be set');
  }
  const pool = new Pool({ connectionString: databaseUrl });

  const schemaSql = readFileSync(join(here, '../migrations/0001_schema.sql'), 'utf8');
  const rlsSql = readFileSync(join(here, '../migrations/0002_rls.sql'), 'utf8');

  const all = [schemaSql, rlsSql].join('\n');
  // Split on `-- SPLIT` markers so each statement executes individually.
  const statements = all
    .split(/--\s*SPLIT\s*/g)
    .map((s) => s.trim())
    .filter(Boolean);

  try {
    for (const stmt of statements) {
      // eslint-disable-next-line no-console
      console.log(`> applying: ${stmt.split('\n')[0].slice(0, 72)}...`);
      await pool.query(stmt);
    }
    // eslint-disable-next-line no-console
    console.log('migration complete');
  } finally {
    await pool.end();
  }
}

main().catch((err: unknown) => {
  // eslint-disable-next-line no-console
  console.error('migration failed:', err);
  process.exit(1);
});
