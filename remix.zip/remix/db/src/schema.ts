import { sql } from 'drizzle-orm';
import {
  pgTable,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  // Clerk user id (string). We map Clerk's string id to a stable UUID via the
  // `external_id` column. The primary key stays a uuid so we can foreign-key
  // from remix_jobs and friends without widening the column type.
  externalId: text('external_id').notNull().unique(),
  email: text('email').notNull().unique(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const remixJobs = pgTable('remix_jobs', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  sourceType: text('source_type').notNull(), // 'upload' | 'url'
  sourceUrl: text('source_url'),
  sourcePlatform: text('source_platform').notNull(), // tiktok | instagram | youtube | x | upload
  sourceVideoStorageUrl: text('source_video_storage_url'),
  sourceDurationSeconds: integer('source_duration_seconds'),
  sourceAspectRatio: text('source_aspect_ratio'),
  transcript: text('transcript'),
  transcriptWords: jsonb('transcript_words'),
  keyframeUrls: jsonb('keyframe_urls'),
  sourceAnalysis: jsonb('source_analysis'),
  swapSpec: jsonb('swap_spec'),
  preserveOriginalAudio: boolean('preserve_original_audio')
    .notNull()
    .default(true),
  captionPreset: text('caption_preset'),
  modelId: text('model_id'),
  generatedVideoUrl: text('generated_video_url'),
  status: text('status').notNull().default('pending'),
  errorMessage: text('error_message'),
  costCents: integer('cost_cents'),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  completedAt: timestamp('completed_at', { withTimezone: true }),
});

export const remixRecipes = pgTable('remix_recipes', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  sourceJobId: uuid('source_job_id')
    .notNull()
    .references(() => remixJobs.id, { onDelete: 'cascade' }),
  recipeName: text('recipe_name').notNull(),
  preserveFields: jsonb('preserve_fields'),
  swapTemplate: jsonb('swap_template'),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const remixBatchRuns = pgTable('remix_batch_runs', {
  id: uuid('id').primaryKey().defaultRandom(),
  recipeId: uuid('recipe_id')
    .notNull()
    .references(() => remixRecipes.id, { onDelete: 'cascade' }),
  variants: jsonb('variants'),
  jobIds: jsonb('job_ids'),
  status: text('status').notNull().default('pending'),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// Re-export the SQL helper for RLS migration authoring elsewhere.
export { sql };
