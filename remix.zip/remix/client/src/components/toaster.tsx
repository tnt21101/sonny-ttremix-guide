import { useToast } from '@/lib/use-toast.js';
import { cn } from '@/lib/utils.js';

export function Toaster(): JSX.Element {
  const { toasts, dismiss } = useToast();
  return (
    <div className="fixed bottom-4 right-4 z-50 flex max-w-sm flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            'rounded-md border bg-card p-4 shadow-lg',
            t.variant === 'destructive' ? 'border-destructive text-destructive' : '',
          )}
          onClick={() => dismiss(t.id)}
        >
          <div className="text-sm font-semibold">{t.title}</div>
          {t.description ? (
            <div className="text-xs text-muted-foreground">{t.description}</div>
          ) : null}
        </div>
      ))}
    </div>
  );
}
