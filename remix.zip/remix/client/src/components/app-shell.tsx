import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { UserButton } from '@clerk/clerk-react';

export function AppShell({ children }: { children: ReactNode }): JSX.Element {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/dashboard" className="flex items-center gap-2 text-lg font-bold">
            <span className="rounded-md bg-primary px-2 py-1 text-primary-foreground">R</span>
            Remix
          </Link>
          <nav className="flex items-center gap-4">
            <Link to="/dashboard" className="text-sm text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link
              to="/remix/new"
              className="rounded-md bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:bg-primary/90"
            >
              New remix
            </Link>
            <UserButton afterSignOutUrl="/login" />
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  );
}
