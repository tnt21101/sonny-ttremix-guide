import { cn } from '@/lib/utils.js';

const STEPS = [
  { id: 1, label: 'Source' },
  { id: 2, label: 'Analyze' },
  { id: 3, label: 'Swap' },
  { id: 4, label: 'Generate' },
  { id: 5, label: 'Polish' },
];

export interface StepIndicatorProps {
  current: number;
}

export function StepIndicator({ current }: StepIndicatorProps): JSX.Element {
  return (
    <ol className="flex items-center gap-3">
      {STEPS.map((s, i) => {
        const isActive = s.id === current;
        const isDone = s.id < current;
        return (
          <li key={s.id} className="flex items-center gap-3">
            <div
              className={cn(
                'flex h-8 w-8 items-center justify-center rounded-full border text-sm font-semibold',
                isActive
                  ? 'border-primary bg-primary text-primary-foreground'
                  : isDone
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-input text-muted-foreground',
              )}
            >
              {s.id}
            </div>
            <span
              className={cn(
                'text-sm',
                isActive ? 'font-medium text-foreground' : 'text-muted-foreground',
              )}
            >
              {s.label}
            </span>
            {i < STEPS.length - 1 ? <div className="h-px w-6 bg-border" /> : null}
          </li>
        );
      })}
    </ol>
  );
}
