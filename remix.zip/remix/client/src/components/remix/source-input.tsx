import { useCallback, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApi } from '@/lib/use-api.js';
import { Button } from '@/components/ui/button.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Input } from '@/components/ui/input.js';
import { Label } from '@/components/ui/label.js';
import { Badge } from '@/components/ui/badge.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.js';
import { useToast } from '@/lib/use-toast.js';

const MAX_UPLOAD_BYTES = 100 * 1024 * 1024;
const ALLOWED_MIMES = ['video/mp4', 'video/quicktime'];

function guessPlatform(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host.includes('tiktok')) return 'TikTok';
    if (host.includes('youtube') || host === 'youtu.be') return 'YouTube';
    if (host.includes('twitter') || host.includes('x.com')) return 'X / Twitter';
    if (
      host.includes('facebook') ||
      host === 'fb.watch' ||
      host.endsWith('.fb.watch') ||
      host === 'fb.com' ||
      host.endsWith('.fb.com')
    ) {
      return 'Facebook';
    }
    if (/\.mp4$/i.test(parsed.pathname)) return 'Direct MP4';
    return null;
  } catch {
    return null;
  }
}

export function SourceInput(): JSX.Element {
  const api = useApi();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [url, setUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);

  const platform = guessPlatform(url);

  const handleUrlSubmit = useCallback(async () => {
    if (!url) return;
    setSubmitting(true);
    try {
      const job = await api.createJob({ sourceType: 'url', sourceUrl: url });
      navigate(`/remix/${job.id}`);
    } catch (err) {
      toast({
        title: 'Failed to start remix',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }, [api, navigate, toast, url]);

  const handleFileSelected = useCallback(
    async (file: File) => {
      if (file.size > MAX_UPLOAD_BYTES) {
        toast({
          title: 'File too large',
          description: 'Max 100MB',
          variant: 'destructive',
        });
        return;
      }
      if (!ALLOWED_MIMES.includes(file.type)) {
        toast({
          title: 'Unsupported file type',
          description: 'Upload an MP4 or MOV',
          variant: 'destructive',
        });
        return;
      }
      const durationSeconds = await probeDuration(file);
      if (durationSeconds > 60) {
        toast({
          title: 'Too long',
          description: 'Videos must be 60 seconds or less',
          variant: 'destructive',
        });
        return;
      }

      setSubmitting(true);
      try {
        setUploadProgress('Requesting signed URL...');
        const signed = await api.requestSignedUpload({
          filename: file.name,
          contentType: file.type,
          sizeBytes: file.size,
        });

        setUploadProgress('Uploading to storage...');
        const putRes = await fetch(signed.uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': file.type },
          body: file,
        });
        if (!putRes.ok) {
          throw new Error(`Upload failed (${putRes.status})`);
        }

        setUploadProgress('Creating remix job...');
        const job = await api.createJob({
          sourceType: 'upload',
          sourceStorageKey: signed.storageKey,
          sourceFilename: file.name,
        });
        navigate(`/remix/${job.id}`);
      } catch (err) {
        toast({
          title: 'Upload failed',
          description: String(err),
          variant: 'destructive',
        });
      } finally {
        setSubmitting(false);
        setUploadProgress(null);
      }
    },
    [api, navigate, toast],
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Source video</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="url">
          <TabsList>
            <TabsTrigger value="upload">Upload video</TabsTrigger>
            <TabsTrigger value="url">Paste URL</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-4">
            <div
              className="flex flex-col items-center justify-center rounded-md border-2 border-dashed border-input py-10 text-center"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files[0];
                if (file) void handleFileSelected(file);
              }}
            >
              <p className="mb-2 text-sm text-muted-foreground">
                Drag and drop an MP4 or MOV, or click below
              </p>
              <p className="mb-4 text-xs text-muted-foreground">
                Max 100MB, 60 seconds. No audio-only files.
              </p>
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={submitting}
              >
                Choose file
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/quicktime"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void handleFileSelected(file);
                }}
              />
            </div>
            {uploadProgress ? (
              <p className="text-sm text-muted-foreground">{uploadProgress}</p>
            ) : null}
          </TabsContent>

          <TabsContent value="url" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="source-url">Video URL</Label>
              <div className="flex gap-2">
                <Input
                  id="source-url"
                  placeholder="https://www.tiktok.com/@user/video/..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
                {platform ? <Badge variant="secondary">{platform}</Badge> : null}
              </div>
              <p className="text-xs text-muted-foreground">
                Supports TikTok, YouTube Shorts, X / Twitter, Facebook Reels, and direct .mp4 URLs.
              </p>
            </div>
            <Button onClick={handleUrlSubmit} disabled={!url || submitting}>
              {submitting ? 'Starting...' : 'Start ingestion'}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

async function probeDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      URL.revokeObjectURL(video.src);
      resolve(video.duration);
    };
    video.onerror = () => reject(new Error('could not read video metadata'));
    video.src = URL.createObjectURL(file);
  });
}
