import { useState } from 'react';
import type { RemixJob, CaptionPreset, SwapSpec as SwapSpecType } from '@remix/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Badge } from '@/components/ui/badge.js';
import { Textarea } from '@/components/ui/textarea.js';
import { Input } from '@/components/ui/input.js';
import { Label } from '@/components/ui/label.js';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.js';
import { Switch } from '@/components/ui/switch.js';
import { Button } from '@/components/ui/button.js';
import { useApi } from '@/lib/use-api.js';
import { useToast } from '@/lib/use-toast.js';

export interface SwapSpecProps {
  job: RemixJob;
  onSaved: () => void;
}

const CAPTION_PRESETS: Array<{ id: CaptionPreset; label: string; description: string }> = [
  { id: 'clean', label: 'Clean', description: 'Small, neutral, sentence-grouped' },
  { id: 'bold', label: 'Bold', description: 'ALL CAPS, high-contrast' },
  { id: 'karaoke', label: 'Karaoke', description: 'Word-by-word sync' },
];

export function SwapSpec({ job, onSaved }: SwapSpecProps): JSX.Element {
  const api = useApi();
  const { toast } = useToast();

  const [mode, setMode] = useState<'describe' | 'reference-image'>(
    job.swapSpec?.character.mode ?? 'describe',
  );
  const [description, setDescription] = useState<string>(
    job.swapSpec?.character.description ?? '',
  );
  const [referenceImageUrl, setReferenceImageUrl] = useState<string>(
    job.swapSpec?.character.referenceImageUrl ?? '',
  );
  const [preserveAudio, setPreserveAudio] = useState<boolean>(job.preserveOriginalAudio);
  const [captionPreset, setCaptionPreset] = useState<CaptionPreset>(
    job.captionPreset ?? 'clean',
  );
  const [saving, setSaving] = useState(false);

  const save = async (): Promise<void> => {
    if (mode === 'describe' && description.trim().length === 0) {
      toast({ title: 'Add a character description', variant: 'destructive' });
      return;
    }
    if (mode === 'reference-image' && referenceImageUrl.trim().length === 0) {
      toast({ title: 'Add a reference image URL', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const swapSpec: SwapSpecType = {
        character: {
          mode,
          description: description.trim().length > 0 ? description : null,
          referenceImageUrl: referenceImageUrl.trim().length > 0 ? referenceImageUrl : null,
        },
        product: null,
      };
      await api.updateSwapSpec(job.id, {
        swapSpec,
        preserveOriginalAudio: preserveAudio,
        captionPreset,
      });
      toast({ title: 'Swap spec saved' });
      onSaved();
    } catch (err) {
      toast({
        title: 'Failed to save swap spec',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Character</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup
            value={mode}
            onValueChange={(v) => setMode(v as 'describe' | 'reference-image')}
          >
            <div className="flex items-center gap-2">
              <RadioGroupItem id="mode-describe" value="describe" />
              <Label htmlFor="mode-describe">Describe change</Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem id="mode-ref" value="reference-image" />
              <Label htmlFor="mode-ref">Upload reference image</Label>
            </div>
          </RadioGroup>

          {mode === 'describe' ? (
            <div className="space-y-1">
              <Label>New character description</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. an astronaut in full spacesuit"
              />
            </div>
          ) : (
            <div className="space-y-1">
              <Label>Reference image URL</Label>
              <Input
                value={referenceImageUrl}
                onChange={(e) => setReferenceImageUrl(e.target.value)}
                placeholder="https://..."
              />
              <p className="text-xs text-muted-foreground">
                The image will be sent to the video model as a character reference.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Product</CardTitle>
          <Badge variant="outline">Coming soon</Badge>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Product swapping will be available in the next release. Phase 1 keeps the original
          product.
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Output options</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Preserve original audio</Label>
              <p className="text-xs text-muted-foreground">
                Replaces the generated audio with the source audio.
              </p>
            </div>
            <Switch
              checked={preserveAudio}
              onCheckedChange={(v: boolean) => setPreserveAudio(v)}
            />
          </div>

          <div className="space-y-2">
            <Label>Caption preset</Label>
            <RadioGroup
              value={captionPreset}
              onValueChange={(v) => setCaptionPreset(v as CaptionPreset)}
              className="grid grid-cols-3 gap-2"
            >
              {CAPTION_PRESETS.map((preset) => (
                <div
                  key={preset.id}
                  className="flex items-start gap-2 rounded-md border p-3"
                >
                  <RadioGroupItem id={`preset-${preset.id}`} value={preset.id} />
                  <div>
                    <Label htmlFor={`preset-${preset.id}`}>{preset.label}</Label>
                    <p className="text-xs text-muted-foreground">{preset.description}</p>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </div>

          <Button onClick={() => void save()} disabled={saving}>
            {saving ? 'Saving...' : 'Save swap spec'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
