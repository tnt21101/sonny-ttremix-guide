import { useEffect, useState } from 'react';
import type { RemixJob, VideoModel } from '@remix/shared';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Label } from '@/components/ui/label.js';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.js';
import { Button } from '@/components/ui/button.js';
import { Badge } from '@/components/ui/badge.js';
import { useApi } from '@/lib/use-api.js';
import { useToast } from '@/lib/use-toast.js';
import { statusLabel } from '@/lib/status-style.js';

export interface GeneratePanelProps {
  job: RemixJob;
  onGenerated: () => void;
}

export function GeneratePanel({ job, onGenerated }: GeneratePanelProps): JSX.Element {
  const api = useApi();
  const { toast } = useToast();

  const { data: models } = useQuery({
    queryKey: ['models'],
    queryFn: () => api.listModels(),
  });

  const defaultModelId =
    models?.find((m) => m.isDefault)?.id ?? 'bytedance/seedance-v1-pro';
  const [selectedModelId, setSelectedModelId] = useState<string>(
    job.modelId ?? defaultModelId,
  );

  useEffect(() => {
    if (!job.modelId && defaultModelId) {
      setSelectedModelId(defaultModelId);
    }
  }, [defaultModelId, job.modelId]);

  const [costCents, setCostCents] = useState<number | null>(null);
  useEffect(() => {
    const duration = job.sourceDurationSeconds ?? 10;
    let cancelled = false;
    api
      .estimateCost(selectedModelId, duration)
      .then((c) => {
        if (!cancelled) setCostCents(c);
      })
      .catch(() => {
        if (!cancelled) setCostCents(null);
      });
    return () => {
      cancelled = true;
    };
  }, [api, selectedModelId, job.sourceDurationSeconds]);

  const [submitting, setSubmitting] = useState(false);
  const triggerGenerate = async (): Promise<void> => {
    setSubmitting(true);
    try {
      await api.triggerGenerate(job.id, selectedModelId);
      toast({ title: 'Generation started' });
      onGenerated();
    } catch (err) {
      toast({
        title: 'Failed to start generation',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const inFlight = ['generating', 'polishing'].includes(job.status);
  const done = job.status === 'complete';

  return (
    <Card>
      <CardHeader>
        <CardTitle>Generate</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Model</Label>
          <RadioGroup
            value={selectedModelId}
            onValueChange={(v) => setSelectedModelId(v)}
            className="grid gap-2"
          >
            {(models ?? []).map((m) => (
              <ModelRow key={m.id} model={m} />
            ))}
          </RadioGroup>
        </div>

        <div className="rounded-md border p-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Estimated cost</div>
              <div className="text-xs text-muted-foreground">
                Based on source duration ({job.sourceDurationSeconds ?? '—'}s). KIE will only
                fire when you click Generate.
              </div>
            </div>
            <div className="text-xl font-bold">
              {costCents !== null
                ? `${(costCents / 100).toLocaleString(undefined, {
                    style: 'currency',
                    currency: 'USD',
                  })}`
                : '—'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={() => void triggerGenerate()} disabled={submitting || inFlight || done}>
            {submitting ? 'Starting...' : done ? 'Already generated' : 'Generate'}
          </Button>
          <Badge variant="secondary">{statusLabel(job.status)}</Badge>
        </div>
      </CardContent>
    </Card>
  );
}

function ModelRow({ model }: { model: VideoModel }): JSX.Element {
  return (
    <div className="flex items-start gap-2 rounded-md border p-3">
      <RadioGroupItem id={`model-${model.id}`} value={model.id} />
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <Label htmlFor={`model-${model.id}`}>{model.label}</Label>
          {model.isDefault ? <Badge variant="secondary">Default</Badge> : null}
        </div>
        <p className="text-xs text-muted-foreground">
          Max {model.maxDurationSeconds}s · {model.supportedAspectRatios.join(', ')} ·
          {` ${(model.costCentsPerSecond / 100).toFixed(2)}/s`}
        </p>
      </div>
    </div>
  );
}
