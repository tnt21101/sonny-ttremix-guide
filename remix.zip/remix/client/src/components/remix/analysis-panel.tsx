import { useEffect, useState } from 'react';
import type { RemixJob, SourceAnalysis } from '@remix/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Input } from '@/components/ui/input.js';
import { Label } from '@/components/ui/label.js';
import { Textarea } from '@/components/ui/textarea.js';
import { Button } from '@/components/ui/button.js';
import { useApi } from '@/lib/use-api.js';
import { useToast } from '@/lib/use-toast.js';

export interface AnalysisPanelProps {
  job: RemixJob;
  onSaved: () => void;
  onReanalyze: () => void;
}

export function AnalysisPanel({ job, onSaved, onReanalyze }: AnalysisPanelProps): JSX.Element {
  const api = useApi();
  const { toast } = useToast();
  const [analysis, setAnalysis] = useState<SourceAnalysis | null>(job.sourceAnalysis);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setAnalysis(job.sourceAnalysis);
  }, [job.sourceAnalysis]);

  if (!analysis) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Analysis</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Analysis is not ready yet. This usually takes 30-60 seconds.
        </CardContent>
      </Card>
    );
  }

  const updateChar = <K extends keyof SourceAnalysis['character']>(
    key: K,
    value: SourceAnalysis['character'][K],
  ): void => {
    setAnalysis({ ...analysis, character: { ...analysis.character, [key]: value } });
  };
  const updateScene = <K extends keyof SourceAnalysis['scene']>(
    key: K,
    value: SourceAnalysis['scene'][K],
  ): void => {
    setAnalysis({ ...analysis, scene: { ...analysis.scene, [key]: value } });
  };
  const updateBlocking = <K extends keyof SourceAnalysis['blocking']>(
    key: K,
    value: SourceAnalysis['blocking'][K],
  ): void => {
    setAnalysis({ ...analysis, blocking: { ...analysis.blocking, [key]: value } });
  };
  const updateCamera = <K extends keyof SourceAnalysis['cameraStyle']>(
    key: K,
    value: SourceAnalysis['cameraStyle'][K],
  ): void => {
    setAnalysis({ ...analysis, cameraStyle: { ...analysis.cameraStyle, [key]: value } });
  };

  const save = async (): Promise<void> => {
    if (!analysis) return;
    setSaving(true);
    try {
      await api.updateAnalysis(job.id, analysis);
      toast({ title: 'Analysis saved' });
      onSaved();
    } catch (err) {
      toast({
        title: 'Failed to save',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Analysis — edit anything that's wrong</CardTitle>
        <Button variant="outline" size="sm" onClick={onReanalyze}>
          Re-analyze
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <Section title="Character">
          <Field
            label="Appearance"
            value={analysis.character.appearance}
            onChange={(v) => updateChar('appearance', v)}
            textarea
          />
          <Field
            label="Age range"
            value={analysis.character.ageRange}
            onChange={(v) => updateChar('ageRange', v)}
          />
          <Field
            label="Vibe"
            value={analysis.character.vibe}
            onChange={(v) => updateChar('vibe', v)}
          />
          <Field
            label="Gender presentation"
            value={analysis.character.genderPresentation}
            onChange={(v) => updateChar('genderPresentation', v)}
          />
        </Section>

        <Section title="Scene">
          <Field
            label="Setting"
            value={analysis.scene.setting}
            onChange={(v) => updateScene('setting', v)}
          />
          <Field
            label="Lighting"
            value={analysis.scene.lighting}
            onChange={(v) => updateScene('lighting', v)}
          />
          <Field
            label="Time of day"
            value={analysis.scene.timeOfDay}
            onChange={(v) => updateScene('timeOfDay', v)}
          />
        </Section>

        <Section title="Blocking">
          <Field
            label="Framing"
            value={analysis.blocking.framing}
            onChange={(v) => updateBlocking('framing', v)}
          />
          <Field
            label="Subject position"
            value={analysis.blocking.subjectPosition}
            onChange={(v) => updateBlocking('subjectPosition', v)}
          />
          <Field
            label="Camera distance"
            value={analysis.blocking.cameraDistance}
            onChange={(v) => updateBlocking('cameraDistance', v)}
          />
        </Section>

        <Section title="Camera style">
          <Field
            label="Movement"
            value={analysis.cameraStyle.movement}
            onChange={(v) => updateCamera('movement', v)}
          />
          <Field
            label="Angle"
            value={analysis.cameraStyle.angle}
            onChange={(v) => updateCamera('angle', v)}
          />
          <Field
            label="Motion feel"
            value={analysis.cameraStyle.motionFeel}
            onChange={(v) => updateCamera('motionFeel', v)}
          />
        </Section>

        <Section title="Actions">
          <Textarea
            value={analysis.actions.join('\n')}
            onChange={(e) =>
              setAnalysis({
                ...analysis,
                actions: e.target.value.split('\n').filter((l) => l.length > 0),
              })
            }
            placeholder="One action per line"
          />
        </Section>

        <Section title="Emotional beats">
          <Textarea
            value={analysis.emotionalBeats.join('\n')}
            onChange={(e) =>
              setAnalysis({
                ...analysis,
                emotionalBeats: e.target.value.split('\n').filter((l) => l.length > 0),
              })
            }
            placeholder="One beat per line"
          />
        </Section>

        <Button onClick={() => void save()} disabled={saving}>
          {saving ? 'Saving...' : 'Save analysis'}
        </Button>
      </CardContent>
    </Card>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }): JSX.Element {
  return (
    <div>
      <h4 className="mb-2 text-sm font-semibold">{title}</h4>
      <div className="grid gap-3 md:grid-cols-2">{children}</div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  textarea,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  textarea?: boolean;
}): JSX.Element {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      {textarea ? (
        <Textarea value={value} onChange={(e) => onChange(e.target.value)} />
      ) : (
        <Input value={value} onChange={(e) => onChange(e.target.value)} />
      )}
    </div>
  );
}
