import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { RemixJob } from '@remix/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Button } from '@/components/ui/button.js';
import { Input } from '@/components/ui/input.js';
import { Label } from '@/components/ui/label.js';
import { useApi } from '@/lib/use-api.js';
import { useToast } from '@/lib/use-toast.js';

export interface PolishPanelProps {
  job: RemixJob;
  onRemixAgain: () => void;
}

export function PolishPanel({ job, onRemixAgain }: PolishPanelProps): JSX.Element {
  const api = useApi();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [recipeName, setRecipeName] = useState('');

  const saveRecipe = async (): Promise<void> => {
    if (recipeName.trim().length === 0) {
      toast({ title: 'Name your recipe first', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      await api.saveRecipe({ sourceJobId: job.id, recipeName: recipeName.trim() });
      toast({
        title: 'Recipe saved',
        description: 'Phase 2 will unlock batch runs.',
      });
      setRecipeName('');
    } catch (err) {
      toast({
        title: 'Failed to save recipe',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (job.status !== 'complete' || !job.generatedVideoUrl) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Polish & publish</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          The final video will appear here once generation and polish finish.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Polish & publish</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <video
          src={job.generatedVideoUrl}
          controls
          className="w-full max-w-md rounded-md border"
        />
        <div className="flex flex-wrap gap-3">
          <Button asChild>
            <a href={job.generatedVideoUrl} download="remix.mp4">
              Download MP4
            </a>
          </Button>
          <Button variant="outline" onClick={onRemixAgain}>
            Remix again with a different character
          </Button>
          <Button variant="ghost" onClick={() => navigate('/dashboard')}>
            Back to dashboard
          </Button>
        </div>
        <div className="space-y-2 rounded-md border p-4">
          <Label>Save as recipe</Label>
          <div className="flex gap-2">
            <Input
              value={recipeName}
              onChange={(e) => setRecipeName(e.target.value)}
              placeholder="e.g. Kitchen energy bar — astronaut swap"
            />
            <Button onClick={() => void saveRecipe()} disabled={saving}>
              {saving ? 'Saving...' : 'Save recipe'}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Phase 2 will let you run this recipe in batch across character variants.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
