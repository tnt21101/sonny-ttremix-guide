import { Routes, Route, Navigate } from 'react-router-dom';
import { SignedIn, SignedOut } from '@clerk/clerk-react';
import { LoginPage } from '@/pages/login.js';
import { DashboardPage } from '@/pages/dashboard.js';
import { NewRemixPage } from '@/pages/remix-new.js';
import { RemixDetailPage } from '@/pages/remix-detail.js';
import { AppShell } from '@/components/app-shell.js';
import { Toaster } from '@/components/toaster.js';

export function App(): JSX.Element {
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/"
          element={
            <>
              <SignedIn>
                <Navigate to="/dashboard" replace />
              </SignedIn>
              <SignedOut>
                <Navigate to="/login" replace />
              </SignedOut>
            </>
          }
        />
        <Route
          path="/dashboard"
          element={
            <Protected>
              <AppShell>
                <DashboardPage />
              </AppShell>
            </Protected>
          }
        />
        <Route
          path="/remix/new"
          element={
            <Protected>
              <AppShell>
                <NewRemixPage />
              </AppShell>
            </Protected>
          }
        />
        <Route
          path="/remix/:id"
          element={
            <Protected>
              <AppShell>
                <RemixDetailPage />
              </AppShell>
            </Protected>
          }
        />
      </Routes>
      <Toaster />
    </>
  );
}

function Protected({ children }: { children: JSX.Element }): JSX.Element {
  return (
    <>
      <SignedIn>{children}</SignedIn>
      <SignedOut>
        <Navigate to="/login" replace />
      </SignedOut>
    </>
  );
}
