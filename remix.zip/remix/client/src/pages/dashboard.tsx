import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useApi } from '@/lib/use-api.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Badge } from '@/components/ui/badge.js';
import { Button } from '@/components/ui/button.js';
import { statusLabel, statusTone } from '@/lib/status-style.js';

export function DashboardPage(): JSX.Element {
  const api = useApi();
  const { data, isLoading, error } = useQuery({
    queryKey: ['remix-jobs'],
    queryFn: () => api.listJobs(),
    refetchInterval: 4000,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Your remixes</h1>
          <p className="text-sm text-muted-foreground">
            Ingest a video, swap the main character, publish.
          </p>
        </div>
        <Button asChild>
          <Link to="/remix/new">New remix</Link>
        </Button>
      </div>
      {isLoading ? <p className="text-sm text-muted-foreground">Loading...</p> : null}
      {error ? (
        <p className="text-sm text-destructive">Failed to load jobs: {String(error)}</p>
      ) : null}
      {data && data.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No remixes yet. Start by creating one.
          </CardContent>
        </Card>
      ) : null}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {data?.map((job) => (
          <Link key={job.id} to={`/remix/${job.id}`} className="block">
            <Card className="transition-shadow hover:shadow-md">
              <CardHeader className="space-y-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    {job.sourcePlatform === 'upload'
                      ? 'Uploaded video'
                      : job.sourceUrl ?? 'URL source'}
                  </CardTitle>
                  <Badge variant={statusTone(job.status)}>{statusLabel(job.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-1 text-xs text-muted-foreground">
                <div>Platform: {job.sourcePlatform}</div>
                <div>Duration: {job.sourceDurationSeconds ?? '—'}s</div>
                <div>Created: {new Date(job.createdAt).toLocaleString()}</div>
                {job.errorMessage ? (
                  <div className="text-destructive">{job.errorMessage}</div>
                ) : null}
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
