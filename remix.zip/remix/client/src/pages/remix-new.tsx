import { SourceInput } from '@/components/remix/source-input.js';
import { StepIndicator } from '@/components/remix/step-indicator.js';

export function NewRemixPage(): JSX.Element {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">New remix</h1>
        <p className="text-sm text-muted-foreground">
          Step 1: pick a source. Once ingestion starts, you'll move through analysis, swap, and
          generation.
        </p>
      </div>
      <StepIndicator current={1} />
      <SourceInput />
    </div>
  );
}
