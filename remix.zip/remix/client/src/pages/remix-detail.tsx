import { useMemo, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import type { RemixJob } from '@remix/shared';
import { useApi } from '@/lib/use-api.js';
import { useToast } from '@/lib/use-toast.js';
import { StepIndicator } from '@/components/remix/step-indicator.js';
import { AnalysisPanel } from '@/components/remix/analysis-panel.js';
import { SwapSpec } from '@/components/remix/swap-spec.js';
import { GeneratePanel } from '@/components/remix/generate-panel.js';
import { PolishPanel } from '@/components/remix/polish-panel.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.js';
import { Badge } from '@/components/ui/badge.js';
import { statusLabel, statusTone } from '@/lib/status-style.js';

function computeCurrentStep(job: RemixJob): number {
  if (job.status === 'ingesting' || job.status === 'pending') {
    return job.sourceAnalysis ? 3 : 2;
  }
  if (job.status === 'analyzing') return 2;
  if (job.status === 'generating') return 4;
  if (job.status === 'polishing') return 5;
  if (job.status === 'complete') return 5;
  if (job.status === 'failed') return 2;
  return 2;
}

export function RemixDetailPage(): JSX.Element {
  const { id } = useParams<{ id: string }>();
  const api = useApi();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: job, error } = useQuery({
    queryKey: ['remix-job', id],
    queryFn: () => (id ? api.getJob(id) : Promise.reject(new Error('no id'))),
    enabled: Boolean(id),
    refetchInterval: (query) => {
      const data = query.state.data;
      if (!data) return 2000;
      if (data.status === 'complete' || data.status === 'failed') return false;
      return 2500;
    },
  });

  const reanalyzing = useRef(false);
  const reanalyze = async (): Promise<void> => {
    if (!id || reanalyzing.current) return;
    reanalyzing.current = true;
    try {
      await api.reanalyze(id);
      toast({ title: 'Re-analysis queued' });
      void queryClient.invalidateQueries({ queryKey: ['remix-job', id] });
    } catch (err) {
      toast({
        title: 'Re-analysis failed',
        description: String(err),
        variant: 'destructive',
      });
    } finally {
      reanalyzing.current = false;
    }
  };

  const refresh = (): void => {
    void queryClient.invalidateQueries({ queryKey: ['remix-job', id] });
  };

  const currentStep = useMemo(() => (job ? computeCurrentStep(job) : 1), [job]);

  if (error) {
    return (
      <Card>
        <CardContent className="py-8 text-destructive">Failed to load: {String(error)}</CardContent>
      </Card>
    );
  }
  if (!job) {
    return <p className="text-sm text-muted-foreground">Loading...</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Remix — {job.id.slice(0, 8)}</h1>
          <p className="text-sm text-muted-foreground">
            Source: {job.sourcePlatform}{' '}
            {job.sourceUrl ? (
              <a
                href={job.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="underline underline-offset-2"
              >
                {job.sourceUrl}
              </a>
            ) : null}
          </p>
        </div>
        <Badge variant={statusTone(job.status)}>{statusLabel(job.status)}</Badge>
      </div>
      <StepIndicator current={currentStep} />

      {job.errorMessage ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">This job failed</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-destructive">{job.errorMessage}</CardContent>
        </Card>
      ) : null}

      <IngestProgress job={job} />

      <AnalysisPanel job={job} onSaved={refresh} onReanalyze={() => void reanalyze()} />

      {job.sourceAnalysis ? (
        <SwapSpec job={job} onSaved={refresh} />
      ) : null}

      {job.swapSpec ? <GeneratePanel job={job} onGenerated={refresh} /> : null}

      <PolishPanel job={job} onRemixAgain={refresh} />
    </div>
  );
}

function IngestProgress({ job }: { job: RemixJob }): JSX.Element | null {
  if (job.status !== 'ingesting' && job.status !== 'analyzing') return null;
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {job.status === 'ingesting'
            ? 'Downloading and storing source...'
            : 'Extracting keyframes, transcribing, and analyzing...'}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        This usually takes 30-60 seconds. You can leave this page — progress will resume when you
        come back.
      </CardContent>
    </Card>
  );
}
