import { SignIn, SignedIn, SignedOut } from '@clerk/clerk-react';
import { Navigate } from 'react-router-dom';

export function LoginPage(): JSX.Element {
  return (
    <>
      <SignedIn>
        <Navigate to="/dashboard" replace />
      </SignedIn>
      <SignedOut>
        <div className="flex min-h-screen items-center justify-center bg-muted/30 px-6">
          <div className="w-full max-w-md space-y-6">
            <div className="space-y-2 text-center">
              <div className="inline-flex items-center gap-2 text-2xl font-bold">
                <span className="rounded-md bg-primary px-2 py-1 text-primary-foreground">R</span>
                Remix
              </div>
              <p className="text-sm text-muted-foreground">
                Sign in to ingest videos and regenerate them with a new character.
              </p>
            </div>
            <div className="flex justify-center">
              <SignIn afterSignInUrl="/dashboard" afterSignUpUrl="/dashboard" />
            </div>
          </div>
        </div>
      </SignedOut>
    </>
  );
}
