import type { RemixJobStatus } from '@remix/shared';

export function statusLabel(status: RemixJobStatus): string {
  switch (status) {
    case 'pending':
      return 'Pending';
    case 'ingesting':
      return 'Ingesting';
    case 'analyzing':
      return 'Analyzing';
    case 'generating':
      return 'Generating';
    case 'polishing':
      return 'Polishing';
    case 'complete':
      return 'Complete';
    case 'failed':
      return 'Failed';
    default:
      return status;
  }
}

export function statusTone(
  status: RemixJobStatus,
): 'default' | 'secondary' | 'destructive' | 'outline' {
  if (status === 'failed') return 'destructive';
  if (status === 'complete') return 'default';
  if (status === 'pending') return 'outline';
  return 'secondary';
}
