import { useCallback, useSyncExternalStore } from 'react';

export interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: 'default' | 'destructive';
}

let toasts: Toast[] = [];
const listeners = new Set<() => void>();

function emit(): void {
  for (const l of listeners) l();
}

function subscribe(l: () => void): () => void {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

function getSnapshot(): Toast[] {
  return toasts;
}

export function useToast(): {
  toasts: Toast[];
  toast: (t: Omit<Toast, 'id'>) => void;
  dismiss: (id: string) => void;
} {
  const current = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  const toast = useCallback((t: Omit<Toast, 'id'>) => {
    const id = crypto.randomUUID();
    toasts = [...toasts, { ...t, id }];
    emit();
    setTimeout(() => {
      toasts = toasts.filter((x) => x.id !== id);
      emit();
    }, 4000);
  }, []);
  const dismiss = useCallback((id: string) => {
    toasts = toasts.filter((x) => x.id !== id);
    emit();
  }, []);
  return { toasts: current, toast, dismiss };
}
