import type {
  CreateRemixJobRequest,
  CreateRemixJobResponse,
  GetRemixJobResponse,
  ListRemixJobsResponse,
  SignedUploadUrlRequest,
  SignedUploadUrlResponse,
  UpdateSwapSpecRequest,
  RemixJob,
  SourceAnalysis,
  VideoModel,
} from '@remix/shared';

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '/api';

export interface ApiClientOptions {
  getToken: () => Promise<string | null>;
}

export class ApiClient {
  public constructor(private readonly options: ApiClientOptions) {}

  private async request<T>(
    path: string,
    init: RequestInit = {},
  ): Promise<T> {
    const token = await this.options.getToken();
    const headers = new Headers(init.headers);
    if (token) headers.set('Authorization', `Bearer ${token}`);
    if (init.body && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }
    const res = await fetch(`${API_BASE}${path}`, { ...init, headers });
    const text = await res.text();
    const payload = text ? JSON.parse(text) : null;
    if (!res.ok) {
      const message =
        (payload && typeof payload === 'object' && 'error' in payload
          ? String(payload.error)
          : null) ?? `Request failed (${res.status})`;
      throw new Error(message);
    }
    return payload as T;
  }

  public async me(): Promise<{ id: string; email: string }> {
    return this.request('/auth/me');
  }

  public async listJobs(): Promise<RemixJob[]> {
    const { jobs } = await this.request<ListRemixJobsResponse>('/remix');
    return jobs;
  }

  public async getJob(id: string): Promise<RemixJob> {
    const { job } = await this.request<GetRemixJobResponse>(`/remix/${id}`);
    return job;
  }

  public async createJob(payload: CreateRemixJobRequest): Promise<RemixJob> {
    const res = await this.request<CreateRemixJobResponse>('/remix', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.job;
  }

  public async updateAnalysis(id: string, analysis: SourceAnalysis): Promise<RemixJob> {
    const res = await this.request<{ job: RemixJob }>(`/remix/${id}/analysis`, {
      method: 'PATCH',
      body: JSON.stringify(analysis),
    });
    return res.job;
  }

  public async updateSwapSpec(
    id: string,
    payload: UpdateSwapSpecRequest,
  ): Promise<RemixJob> {
    const res = await this.request<{ job: RemixJob }>(`/remix/${id}/swap-spec`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    return res.job;
  }

  public async reanalyze(id: string): Promise<void> {
    await this.request(`/remix/${id}/reanalyze`, { method: 'POST' });
  }

  public async triggerGenerate(id: string, modelId: string): Promise<void> {
    await this.request(`/remix/${id}/generate`, {
      method: 'POST',
      body: JSON.stringify({ modelId }),
    });
  }

  public async estimateCost(modelId: string, durationSeconds: number): Promise<number> {
    const res = await this.request<{ costCents: number }>('/remix/cost-estimate', {
      method: 'POST',
      body: JSON.stringify({ modelId, durationSeconds }),
    });
    return res.costCents;
  }

  public async requestSignedUpload(
    payload: SignedUploadUrlRequest,
  ): Promise<SignedUploadUrlResponse> {
    return this.request('/upload/signed-url', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  public async listModels(): Promise<VideoModel[]> {
    const res = await this.request<{ models: VideoModel[] }>('/models');
    return res.models;
  }

  public async saveRecipe(params: {
    sourceJobId: string;
    recipeName: string;
  }): Promise<{ id: string }> {
    const res = await this.request<{ recipe: { id: string } }>('/recipes', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    return { id: res.recipe.id };
  }
}
