import { useMemo } from 'react';
import { useAuth } from '@clerk/clerk-react';
import { ApiClient } from './api.js';

export function useApi(): ApiClient {
  const { getToken } = useAuth();
  return useMemo(() => new ApiClient({ getToken }), [getToken]);
}
