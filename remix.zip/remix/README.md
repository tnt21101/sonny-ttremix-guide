# Remix

A video remix app. Ingest a source video (upload or URL from TikTok, IG Reels, YT Shorts, X) and regenerate it with the main character swapped — script, scene, blocking, camera, and meaning preserved.

## Tech stack

- Frontend: React + Vite + TypeScript + Tailwind + shadcn-style primitives (hand-rolled on Radix UI)
- Backend: Node 20 + Express + TypeScript (strict)
- Database: Neon (Postgres) via drizzle ORM
- Auth: **Clerk** (see below)
- Storage: AWS S3 (the spec allows R2 or S3 — we use S3 because AWS credentials are already in the env)
- Ingestion: yt-dlp system binary + youtube-dl-exec
- Processing: FFmpeg system binary + fluent-ffmpeg
- Transcription: OpenAI Whisper API (word-level timestamps)
- Vision analysis: Claude Sonnet via Anthropic SDK
- Prompt generation: Claude Sonnet
- Video generation: KIE.ai gateway, default `bytedance/seedance-v1-pro`, alternates `kling-3.0`, `veo-3.1`
- Queue: BullMQ + Redis

### Why Clerk (not Neon Auth)

Both options are viable. We picked Clerk because:

1. The user provided working Clerk keys (`pk_test_...` and `sk_test_...`).
2. Clerk's `@clerk/clerk-react` + `@clerk/express` split maps cleanly onto the Vite SPA + Express backend split this project uses.
3. Neon Auth (Stack Auth) would require additional wiring in the Neon dashboard and a project-level migration that we didn't have a credential for.

> Note: Clerk's published Next.js App Router docs do not apply here — this project is React-SPA + Express, not Next.js. We use `@clerk/clerk-react` on the client and `@clerk/express` for the Express `clerkMiddleware()` + `getAuth(req)` pattern.

## Repository layout

```
remix/
  client/   — Vite + React frontend
  server/   — Express backend + BullMQ pipeline workers
  db/       — drizzle schema, migrations (schema + RLS)
  shared/   — shared TypeScript types (no runtime code)
  package.json — pnpm workspaces root
```

## Prerequisites

- Node 20+
- pnpm 9+
- FFmpeg (`ffmpeg -version`)
- yt-dlp (`yt-dlp --version`)
- Redis (`redis-server`)
- An `.env` at the repo root (see `.env` template)

## First-time setup

```bash
pnpm install
pnpm --filter @remix/db migrate       # creates schema + RLS on Neon
```

## Running locally

```bash
# terminal 1 — redis
redis-server

# terminal 2 — API
pnpm --filter @remix/server dev

# terminal 3 — pipeline workers
pnpm --filter @remix/server worker

# terminal 4 — frontend
pnpm --filter @remix/client dev
```

Then open http://localhost:5173.

## Validation

```bash
pnpm typecheck   # tsc --noEmit across client, server, shared
pnpm test        # vitest specs for ingest-source, analyze-source, build-remix-prompt, model-registry, platform-detect
```

## Pipeline contract

```
ingest-source → analyze-source → (user configures swap) → build-remix-prompt → generate-remix → polish-remix
```

Every worker writes to `remix_jobs` at every state transition so users can leave mid-flow and resume. The paid KIE call is gated behind the Generate button — nothing else auto-fires it.

## Phase 1 scope

- Auth
- URL + upload ingestion
- Analyze (keyframes, Whisper transcription, Claude Vision)
- Character swap (describe or reference image)
- Generate (Seedance default, Kling / Veo alternates)
- Polish (caption burn, optional original-audio preservation)
- Download MP4
- "Save as recipe" writes a row and shows a toast

## Phase 2 stubs (present in schema, not exercised by Phase 1 code)

- `remix_recipes` — one recipe row per "save as recipe" click
- `remix_batch_runs` — future batch runner

Product swap slots exist in the swap-spec type but the Phase 1 UI disables product swap with a "Coming soon" badge, and the server rejects non-null product swaps.
